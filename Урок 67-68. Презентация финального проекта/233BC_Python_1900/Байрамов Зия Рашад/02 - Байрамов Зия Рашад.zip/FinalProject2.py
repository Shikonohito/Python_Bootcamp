from datetime import datetime


class BankCard:

  def __init__(self, card_id: int,
               exp_date: int, ccv: int):
    self.__id = card_id
    self.__expdate = exp_date
    self.__ccv = ccv

  def __str__(self):
    res = f'{self.__id} {self.__fname} {self.__lname} {self.__balance}'
    return res

  def set_first_name(self, first_name: str):
    self.__fname = first_name

  def get_first_name(self):
    return self.__fname

  def set_last_name(self, last_name: str):
    self.__lname = last_name

  def get_last_name(self):
    return self.__lname

  def set_card_id(self, card_id: str):
    self.__id = card_id

  def get_card_id(self):
    return self.__id

  def set_exp_month(self, exp_month: int):
    if 1 <= exp_month <= 12:
      self.__month = exp_month
    else:
      self.__month = 1

  def get_exp_month(self):
    return self.__month

  def set_exp_year(self, exp_year: int):
    if 1900 <= exp_year <= 2028:
      self.__year = exp_year
    else:
      self.__year = 2028

  def get_exp_year(self):
    return self.__year

  def set_balance(self, balance: int):
    if balance >= 0:
      self.__balance = balance
    else:
      self.__balance = 0

  def get_balance(self):
    return self.__balance

  def withdraw(self, money: int) -> bool:
    if 0 <= money <= self.__balance:
      self.__balance -= money
      return True
    return False

  def deposit(self, money: int) -> bool:
    if money > 0:
      self.__balance += money
      return True
    return False

  def process_transaction(self, amount: int) -> bool:
    if amount > 0 and amount <= self.__balance:
      self.__balance -= amount
      return True
    return False

  def attach_card(self, customer):
    customer.cards.append(self)

class Client:

  def __init__(self, client_id, name, age, address):
    self.__client_id = client_id
    self.__name = name
    self.__age = age
    self.__address = address
    self.__reservations = []
    self.__cards = list()

  def get_client_id(self) -> str:
    return self.__client_id

  def get_name(self) -> str:
    return self.__name

  def get_age(self) -> int:
    return self.__age

  def get_address(self) -> str:
    return self.__address

  def get_reservations(self) -> list:
    return self.__reservations

  def add_reservation(self, reservation):
    self.__reservations.append(reservation)

  def remove_reservation(self, reservation_id: str):
    reservation = self.reservation_searcher(reservation_id)
    if reservation:
      self.__reservations.remove(reservation)

  def reservation_searcher(self, reservation_id: str):
    for reservation in self.__reservations:
      if reservation.get_reservation_id() == reservation_id:
        return reservation
    return None

  def get_info(self) -> dict:
    return {
        'client_id': self.__client_id,
        'name': self.__name,
        'age': self.__age,
        'address': self.__address
    }

  def update_info(self, updated_name: str, updated_age: int,
                  updated_address: str) -> None:
    self.__name = updated_name
    self.__age = updated_age
    self.__address = updated_address

  def attach_card(self, card: dict) -> None:
    self.__cards.append(card)

  def get_card(self, card_index: int) -> dict | None:
    if 0 <= card_index < len(self.__cards):
      return self.__cards[card_index]
    return None

  def get_cards(self) -> list:
    return self.__cards

  def remove_card(self, card_index: int) -> None:
    if 0 <= card_index < len(self.__cards):
      del self.__cards[card_index]

  def make_reservation(self, room, start_date: int, end_date: int, Database):
    if room.get_status() == "Free":
      reservation_id = f"R{len(self.__reservations) + 1:03d}"
      reservation = Reservation(reservation_id, self, room, start_date,
                                end_date)
      self.add_reservation(reservation)
      room.set_status("Reserved")
      Database.add_reservation(reservation)
      return reservation
    return None

  def cancel_reservation(self, reservation_id: str, Database) -> bool:
    reservation = self.reservation_searcher(reservation_id)
    if reservation:
      room = reservation.get_room()
      room.set_status("Free")
      self.remove_reservation(reservation_id)
      Database.remove_reservation(reservation_id)
      return True
    return False

  def get_upcoming_reservations(self, current_date: int) -> list:
    upcoming_reservations = []
    for reservation in self.__reservations:
      if reservation.get_start_date() > current_date:
        upcoming_reservations.append(reservation)
    return upcoming_reservations

  def get_total_spent(self, Database) -> int:
    total_spent = 0
    for reservation in self.__reservations:
      total_spent += reservation.get_room().get_price()
    return total_spent


class HotelRoom:

  def __init__(self, room_number: int, room_type: str, room_status: str,
               room_price: int):
    self.__room_number = room_number
    self.__type = room_type
    self.__status = room_status
    self.__price = room_price
    self.__reservation = None
    self.__current_client = None

  def get_room_number(self) -> int:
    return self.__room_number

  def get_type(self) -> str:
    return self.__type

  def get_status(self) -> str:
    return self.__status

  def get_price(self) -> int:
    return self.__price

  def set_status(self, status: str) -> None:
    self.__status = status

  def get_info(self) -> dict:
    return {
        'room_number': self.__room_number,
        'type': self.__type,
        'status': self.__status,
        'price': self.__price
    }

  def update_info(self, updated_type: str, updated_price: int) -> None:
    self.__type = updated_type
    self.__price = updated_price

  def get_reservation(self):
    return self.__reservation

  def set_reservation(self, reservation) -> None:
    self.__reservation = reservation

  def set_currentclient(self, client: Client):
    self.__current_client = client

  def get_currentclient(self) -> Client | None:
    return self.__current_client


class Reservation:
  def __init__(self, client: Client, room_type: str, start_date: int, end_date: int):
      self.__client = client
      self.__room_type = room_type
      self.__start_date = start_date
      self.__end_date = end_date

  def get_client(self) -> Client:
      return self.__client

  def get_room_type(self) -> str:
      return self.__room_type

  def get_start_date(self) -> int:
      return self.__start_date

  def get_end_date(self) -> int:
      return self.__end_date

  def get_info(self) -> dict:
      return {
          'client': self.__client.get_client_id(),
          'room_type': self.__room_type,
          'start_date': self.__start_date,
          'end_date': self.__end_date
      }

  def update_info(self, client: Client, room_type: str, start_date: int, end_date: int) -> None:
      self.__client = client
      self.__room_type = room_type
      self.__start_date = start_date
      self.__end_date = end_date


class Database:

  def __init__(self, clients_list: list, reservations_list: list):
    self.__clients_list = clients_list
    self.__reservations_list = reservations_list

  def calculate_total_cost(self, client: Client) -> int:
    total_cost = 0
    for reservation in client.get_reservations():
      total_cost += reservation.get_room().get_price()
    return total_cost

  def make_payment(self, client: Client) -> bool:
    total_cost = self.calculate_total_cost(client)
    if client.get_cards() and client.get_cards():
      return True
    return False

  def get_clients_list(self) -> list[Client]:
    return self.__clients_list

  def get_reservations_list(self) -> list[Reservation]:
    return self.__reservations_list

  def client_searcher(self, client_id: str) -> Client:
    for client in self.__clients_list:
      if client.get_client_id() == client_id:
        return client
    return None

  def reservation_searcher(self, client: Client):
    for reservation in self.__reservations_list:
        if reservation.get_client() == client:
            return reservation
    return None

  def append_client(self, client: Client) -> None:
    self.__clients_list.append(client)

  def remove_client(self, client_id: str) -> None:
    client = self.client_searcher(client_id)
    if client:
      self.__clients_list.remove(client)

  def add_reservation(self, reservation: Reservation) -> None:
    self.__reservations_list.append(reservation)
  
  def remove_reservation(self, client: Client) -> None:
    reservation = self.reservation_searcher(client)
    if reservation:
      self.__reservations_list.remove(reservation)

  def find_reservation_by_room(self, room_number: int) -> Reservation | None:
    for reservation in self.__reservations_list:
      if reservation.get_room().get_room_number() == room_number:
        return reservation
    return None

  def get_reserved_rooms(self) -> list[HotelRoom]:
    reserved_rooms = []
    for reservation in self.__reservations_list:
      reserved_rooms.append(reservation.get_room())
    return reserved_rooms

  def find_client_by_reservation(self, reservation_id: str) -> Client | None:
    for client in self.__clients_list:
      if reservation_id in [
          r.get_reservation_id() for r in client.get_reservations()
      ]:
        return client
    return None

  def get_reserved_rooms_by_client(self, client_id: str) -> list[HotelRoom]:
    reserved_rooms = []
    client = self.client_searcher(client_id)
    if client:
      for reservation in client.get_reservations():
        reserved_rooms.append(reservation.get_room())
    return reserved_rooms

  def get_active_reservations(self, current_date: int) -> list[Reservation]:
    active_reservations = []
    for reservation in self.__reservations_list:
      if reservation.is_active(current_date):
        active_reservations.append(reservation)
    return active_reservations

  def get_client_reservations(self, client_id: str) -> list[Reservation]:
    client = self.client_searcher(client_id)
    return client.get_reservations() if client else []

  def get_total_earnings(self) -> int:
    total_earnings = 0
    for reservation in self.__reservations_list:
      total_earnings += reservation.get_room().get_price()
    return total_earnings

  def get_room_reservations(self, room_number: int) -> list[Reservation]:
    room = self.room_searcher(room_number)
    return [
        reservation for reservation in self.__reservations_list
        if reservation.get_room() == room
    ]

  def get_overdue_reservations(self, current_date: int) -> list[Reservation]:
    overdue_reservations = []
    for reservation in self.__reservations_list:
      if reservation.get_end_date() < current_date and reservation.is_active(
          current_date):
        overdue_reservations.append(reservation)
    return overdue_reservations

  def make_reservation(self, client: Client, room_types: list[str],
                       start_date: int, end_date: int) -> list[Reservation]:
    if client.get_card():
      reservations = []

      for room_type in room_types:
        available_rooms = self.get_available_rooms_by_type(room_type)

        if available_rooms:
          selected_room = available_rooms[0]
          reservation_id = f"R{len(self.__reservations_list) + 1:03d}"
          reservation = Reservation(reservation_id, client, selected_room,
                                    start_date, end_date)

          total_cost = reservation.get_room().get_price()
          if client.get_card().withdraw(total_cost):
            self.add_reservation(reservation)
            selected_room.set_reservation(reservation)
            selected_room.set_status("Reserved")
            reservations.append(reservation)
          else:
            for res in reservations:
              res_room = res.get_room()
              res_total_cost = res_room.get_price()
              client.get_card().deposit(res_total_cost)
              res_room.set_status("Free")
              client.remove_reservation(res.get_reservation_id())
              self.remove_reservation(res.get_reservation_id())

      return reservations

    return []

  def cancel_reservation_with_refund(self, reservation_id: str) -> bool:
    reservation = self.reservation_searcher(reservation_id)

    if reservation:
      client = reservation.get_client()
      room = reservation.get_room()
      total_cost = room.get_price()

      if client.get_card() and client.get_card().deposit(total_cost):
        room.set_status("Free")
        client.remove_reservation(reservation_id)
        self.remove_reservation(reservation_id)
        return True
      else:
        return False

    return False


import tkinter as tk
from tkinter import ttk
from tkcalendar import Calendar
import pickle
import tkinter.messagebox


clients = []
reservations = []

def save_data():
  data = {'reservations': {}, 'clients': {}}
  for client in clients:
      client_data = {
          'Name': client.get_name(),
          'Age': client.get_age(),
          'Address': client.get_address(),
          'Cards': [card for card in client.get_cards()]
      }
      data['clients'][client.get_name()] = client_data

      if client.get_name() not in data['reservations']:
          data['reservations'][client.get_name()] = []

      reservations = database1.get_reservations_list()
      for reservation in reservations:
          if reservation.get_client().get_name() == client.get_name():
              reservation_data = {
                  'Room Type': reservation.get_room_type(),
                  'Start Date': reservation.get_start_date(),
                  'End Date': reservation.get_end_date()
              }
              data['reservations'][client.get_name()].append(reservation_data)

  with open('data.pickle', 'wb') as file:
      pickle.dump(data, file)

  error_label.config(text="Data saved successfully.")

def load_data():
  global clients, reservations

  try:
      with open('data.pickle', 'rb') as file:
          data = pickle.load(file)
          clients = []
          reservations = []

          for client_name, client_data in data.get('clients', {}).items():
              client_id = client_data.get('Id', None)
              client = Client(client_id, client_name, client_data.get('Age', 0), client_data.get('Address', ''))
              client_cards = client.get_cards()
              client_cards.clear()
              client_cards.extend(client_data.get('Cards', []))
              database1.append_client(client)

          for client_name, reservations_data in data.get('reservations', {}).items():
              client = next((c for c in clients if c.get_name() == client_name), None)
              if client:
                  for reservation_data in reservations_data:
                      room_type = reservation_data['Room Type']
                      start_date = reservation_data['Start Date']
                      end_date = reservation_data['End Date']

                      reservation = Reservation(client, room_type, start_date, end_date)
                      database1.add_reservation(reservation)

          clients_listbox.delete(0, tk.END)
          reserved_rooms_listbox.delete(0, tk.END)
  
          update_clients_list()
          display_reserved_rooms()
          update_client_info()
          update_reserved_rooms_list()

          error_label.config(text="Data loaded successfully.")

  except FileNotFoundError:
      error_label.config(text="No saved data found.")
      clients = []
      reservations = []


database1 = Database(clients, reservations)


def validate_client_input():
  id = id_entry.get()
  first_name = name_entry.get()
  age = age_entry.get()
  address = address_entry.get()

  if first_name == "" or id == "" or address == "" or age == "":
      return False
  return True

def validate_reservation_input():
  start_date = start_date_entry.get()
  end_date = end_date_entry.get()

  if len(start_date) == 0 or len(end_date) == 0:
    return False
  return True

def validate_card_input():
  card_number = card_number_entry.get()
  exp_date = exp_date_entry.get()
  ccv = ccv_entry.get()

  if card_number == "" or exp_date == "" or ccv == "":
      return False
  return True


def add_card():
  clients_list1 = database1.get_clients_list()

  selected_client_str = clients_listbox.get(clients_listbox.curselection())

  if not selected_client_str:
      error_label.config(text="Error: Please select a client.")
      return

  selected_client_dict = eval(selected_client_str)

  selected_client_id = selected_client_dict['Id']

  selected_client = None

  for item in range(len(clients_list1)):
      if clients_list1[item].get_client_id() == selected_client_id:
          selected_client = clients_list1[item]
          break

  if selected_client is None:
      error_label.config(text="Error: No client found with the given ID.")
      return

  card_number = card_number_entry.get()
  exp_date = exp_date_entry.get()
  ccv = ccv_entry.get()

  if not card_number.isdigit() or len(card_number) != 16:
      error_label.config(text="Invalid card number")
      return
  if not exp_date.isdigit() or len(exp_date) != 4:
      error_label.config(text="Invalid expiration date")
      return
  if not ccv.isdigit() or len(ccv) != 3:
      error_label.config(text="Invalid CCV")
      return

  card_info = f"Card Number: {card_number}, Exp. Date: {exp_date}, CCV: {ccv}"

  selected_client.attach_card(card_info)

  index = clients_listbox.get(0, 'end').index(selected_client_str)

  cards_listbox.insert(index + 1, card_info)

  error_label.config(text="")



def delete_card():
  selected_index = cards_listbox.curselection()
  if selected_index:

      confirmation = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to delete this card?")

      if confirmation:
          cards_listbox.delete(selected_index)


          selected_client_info_str = clients_listbox.get(clients_listbox.curselection())
          selected_client_id = selected_client_info_str.split(",")[0].split(":")[1].strip()
          selected_client = database1.client_searcher(selected_client_id)
          if selected_client:
              selected_client.remove_card(selected_index[0])

          error_label.config(text="Card has been deleted.")
      else:
          error_label.config(text="Deletion canceled.")


def add_client():
  if validate_client_input():
      id = id_entry.get()
      name = name_entry.get()
      age = age_entry.get()
      address = address_entry.get()

      existing_client = database1.client_searcher(id)
      if existing_client:
          error_label.config(text="Error: Client with the same ID already exists.")
          return

      try:
          age = int(age)

          if any(char.isdigit() for char in name):
              raise ValueError("Name should not contain digits")

          if age < 0:
            raise ValueError("Age should be a positive integer.")    
          if age > 110:
            raise ValueError("Age should be real.")


          client = Client(id, name, age, address)
          database1.append_client(client)

          update_clients_list()

          id_entry.delete(0, tk.END)
          name_entry.delete(0, tk.END)
          age_entry.delete(0, tk.END)
          address_entry.delete(0, tk.END)

      except ValueError as e:
          error_label.config(text=f"Input error")
  else:
      error_label.config(text="Error: All fields must be filled.")



def delete_client():
  selected_index = clients_listbox.curselection()
  if selected_index:
      selected_client_info_str = clients_listbox.get(selected_index)


      client_id = selected_client_info_str.split(",")[0].split(":")[1].strip()


      confirmation = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to delete this client?")

      if confirmation:
          clients_listbox.delete(selected_index)


          selected_client = database1.client_searcher(client_id)
          if selected_client:
              database1.remove_client(selected_client)

          error_label.config(text="Client has been deleted.")
      else:
          error_label.config(text="Deletion canceled.")
        
          update_clients_list()

def show_client_info():
  selected_index = clients_listbox.curselection()
  if selected_index:
    selected_client_info.set("")
    selected_client_info_str = clients_listbox.get(selected_index)
    client_id = selected_client_info_str.split(",")[0].split(":")[1].strip()

    selected_client = database1.client_searcher(client_id)
    if selected_client:
      selected_client_info.set(f"ID: {selected_client.get_id()}\n"
                               f"Name: {selected_client.get_name()}\n"
                               f"Age: {selected_client.get_age()}\n"
                               f"Address: {selected_client.get_address()}")

      cards_listbox.delete(0, tk.END)

      for card_index, card in enumerate(selected_client.get_card_list()):
        cards_listbox.insert(tk.END, f"Card {card_index + 1}: {card}")

def update_client_info():
  if validate_client_input():
      selected_index = clients_listbox.curselection()
      if selected_index:
          id = id_entry.get()
          name = name_entry.get()
          age = age_entry.get()
          address = address_entry.get()

          try:
              age = int(age)

              if any(char.isdigit() for char in name):
                  raise ValueError("Name should not contain digits")

              if age < 0:
                  raise ValueError("Age should be a positive integer.")    
              if age > 110:
                raise ValueError("Age should be real.")
              updated_client_info = {
                  'Id': id,
                  'Name': name,
                  'Age': age,
                  'Address': address
              }

              clients_listbox.delete(selected_index)
              clients_listbox.insert(selected_index, updated_client_info)

              id_entry.delete(0, tk.END)
              name_entry.delete(0, tk.END)
              age_entry.delete(0, tk.END)
              address_entry.delete(0, tk.END)


          except ValueError as e:
              error_label.config(text=f"Input error")
  else:
      error_label.config(text="Error: All fields must be filled.")


def update_card_list():
  cards_listbox.delete(0, tk.END)
  selected_client_info_str = selected_client_info.get()

  if selected_client_info_str:
    client_id = selected_client_info_str.split(",")[0].split(":")[1].strip()

    selected_client = database1.client_searcher(client_id)
    if selected_client:
      for card_index, card in enumerate(selected_client.get_cards()):
        cards_listbox.insert(tk.END, f"Card {card_index + 1}: {card}")


def update_clients_list():
  clients_listbox.delete(0, tk.END)

  for client in database1.get_clients_list():
      clients_listbox.insert(
          tk.END,
          {
              'Id': client.get_client_id(),
              'Name': client.get_name(),
              'Age': client.get_age(),
              'Address': client.get_address()
          }
      )



def select_client():
  selected_index = clients_listbox.curselection()
  if selected_index:
    selected_client_info.set(clients_listbox.get(selected_index))

def reservate_room():
  global reservations

  if not validate_reservation_input():
      error_label.config(text="Error: All fields must be filled.")
      return

  selected_client_str = clients_listbox.get(clients_listbox.curselection())

  if not selected_client_str:
      error_label.config(text="Please select a client")
      return

  selected_client_dict = eval(selected_client_str)
  selected_client_id = selected_client_dict['Id']

  selected_client = None

  for item in range(len(clients)):
      if clients[item].get_client_id() == selected_client_id:
          selected_client = clients[item]
          break

  if selected_client is None:
      error_label.config(text="Error: No client found with the given ID.")
      return

  start_date = int(start_date_entry.get())
  end_date = int(end_date_entry.get())

  if not all([start_date, end_date]):
      error_label.config(text="Please enter all the fields")
      return

  room_type = room_type_combobox.get()
  new_reservation = Reservation(selected_client, room_type, start_date, end_date)
  reservations.append(new_reservation)
  display_reserved_rooms()
  start_date_entry.delete(0, 'end')
  end_date_entry.delete(0, 'end')
  error_label.config(text="")

from datetime import datetime

def book_room():
  global reservations

  if validate_reservation_input():
    if clients_listbox.curselection():
      selected_client = clients_listbox.get(clients_listbox.curselection())

      selected_client_dict = eval(selected_client)
      selected_client_id = selected_client_dict['Id']
      
      client_sel = database1.client_searcher(selected_client_id)

      room_type = room_type_combobox.get()
      check_in_date = int(start_date_entry.get())
      check_out_date = int(end_date_entry.get())

      if check_in_date < 1 or check_out_date < 1:
          error_label.config(text="Invalid dates")
          return


      new_reservation = Reservation(client_sel, room_type, check_in_date, check_out_date)


      database1.add_reservation(new_reservation)


      display_reserved_rooms()
      start_date_entry.delete(0, 'end')
      end_date_entry.delete(0, 'end')
      error_label.config(text="")
    else:
      error_label.config(text="Please select a client")
  else:
      error_label.config(text="Error: All fields must be filled.")



def update_reserved_rooms_list():
  reserved_rooms_listbox.delete(0, tk.END)

  selected_client_info_str = selected_client_info.get()
  if selected_client_info_str:
      client_id = selected_client_info_str.split(",")[0].split(":")[1].strip()

      selected_client = database1.client_searcher(client_id)
      if selected_client:
          for reservation in selected_client.get_reservations():
              reserved_rooms_listbox.insert(
                  tk.END,
                  f"Room {reservation.get_room().get_room_number()} ({reservation.get_start_date()} - {reservation.get_end_date()})"
                )


def update_available_rooms_list():
  available_rooms = database1.get_free_rooms()
  available_rooms_listbox.delete(0, tk.END)
  for room in available_rooms:
    available_rooms_listbox.insert(
        tk.END,
        f"Room {room.get_room_number()} ({room.get_type()} - {room.get_price()}$)"
    )


def cancel_reservation():
  try:
      selected_reservation = reserved_rooms_listbox.get(tk.ACTIVE)


      confirmation = tkinter.messagebox.askyesno("Confirmation", "Are you sure you want to cancel this reservation?")

      if confirmation:
          reserved_rooms_listbox.delete(tk.ACTIVE)
          error_label.config(text="Reservation has been canceled.")


          selected_client_info_str = selected_client_info.get()
          if selected_client_info_str:
              client_id = selected_client_info_str.split(",")[0].split(":")[1].strip()
              selected_client = database1.client_searcher(client_id)
              if selected_client:
                  database1.remove_reservation(selected_client)
                  update_reserved_rooms_list()
      else:
          error_label.config(text="Cancellation canceled.")
  except tk.TclError:
      error_label.config(text="Please select a reservation to cancel.")



def display_reserved_rooms(selected_date=None):
  reserved_rooms_listbox.delete(0, tk.END)
  for reservation in database1.get_reservations_list():
      if selected_date is None or selected_date in (reservation.start_date, reservation.end_date):

          client_name = reservation.get_client().get_name()

          reservation_info = {
              'Client Name': client_name,
              'Room Type': reservation.get_room_type(),
              'Start Date': reservation.get_start_date(),
              'End Date': reservation.get_end_date()
          }

          reserved_rooms_listbox.insert(tk.END, reservation_info)





def open_client_menu():
  client_frame.place(relx=0, rely=0, relwidth=1, relheight=1)
  card_frame.place(relx=0, rely=0.6, relwidth=1, relheight=0.5)
  reservation_frame.place_forget()
  calendar_frame.place_forget()
  root.update_idletasks()


def open_reservation_menu():
  reservation_frame.place(relx=0, rely=0, relwidth=1, relheight=1)
  calendar_frame.place(relx=0.5, rely=0.1, relwidth=0.45, relheight=0.3)
  client_frame.place_forget()
  card_frame.place_forget()
  root.update_idletasks()


root = tk.Tk()
root.title("Hotel Reservation System")
root.geometry('1000x1000')

menu_bar = tk.Menu(root)
root.config(menu=menu_bar)
menu_bar.add_command(label="Client", command=open_client_menu)
menu_bar.add_command(label="Reservation", command=open_reservation_menu)
menu_bar.add_command(label="Save", command=save_data)
menu_bar.add_command(label="Load", command=load_data)


validation_frame = ttk.Frame(root)
validation_frame.pack()


error_label = tk.Label(validation_frame, text="")
error_label.pack()

validation_frame = ttk.Frame(root)
validation_frame.pack()


client_frame = ttk.LabelFrame(root, text="Clients")

reservation_frame = ttk.LabelFrame(root, text="Room Reservation")

card_frame = ttk.LabelFrame(root, text="Credit Cards")

calendar_frame = ttk.Frame(reservation_frame)

id_label = ttk.Label(client_frame, text="ID:")
id_label.place(relx=0.02, rely=0.02)
id_entry = ttk.Entry(client_frame)
id_entry.place(relx=0.1, rely=0.02)

name_label = ttk.Label(client_frame, text="Name:")
name_label.place(relx=0.02, rely=0.1)
name_entry = ttk.Entry(client_frame)
name_entry.place(relx=0.1, rely=0.1)

age_label = ttk.Label(client_frame, text="Age:")
age_label.place(relx=0.02, rely=0.2)
age_entry = ttk.Entry(client_frame)
age_entry.place(relx=0.1, rely=0.2)

address_label = ttk.Label(client_frame, text="Address:")
address_label.place(relx=0.02, rely=0.3)
address_entry = ttk.Entry(client_frame)
address_entry.place(relx=0.1, rely=0.3)

add_button = ttk.Button(client_frame, text="Add Client", command=add_client)
add_button.place(relx=0.1, rely=0.38)



delete_button = ttk.Button(client_frame,
                           text="Delete Client",
                           command=delete_client)
delete_button.place(relx=0.25, rely=0.38)

show_info_button = ttk.Button(client_frame,
                              text="Show Info",
                              command=show_client_info)
show_info_button.place(relx=0.1, rely=0.48)

update_info_button = ttk.Button(client_frame,
                                text="Update Info",
                                command=update_client_info)
update_info_button.place(relx=0.25, rely=0.48)

clients_listbox = tk.Listbox(client_frame)
clients_listbox.place(relx=0.5, rely=0.02, relwidth=0.45, relheight=0.45)

selected_client_info = tk.StringVar()
client_info_label = ttk.Label(client_frame, textvariable=selected_client_info)
client_info_label.place(relx=0.5, rely=0.5, relwidth=0.45, relheight=0.45)

selected_client_label = ttk.Label(reservation_frame, text="Client:")
selected_client_label.place(relx=0.02, rely=0.56)

selected_client_info_label = ttk.Label(reservation_frame,
                                       textvariable=selected_client_info)
selected_client_info_label.place(relx=0.1, rely=0.56, relwidth=0.4)

select_client_button = ttk.Button(reservation_frame,
                                  text="Select Client",
                                  command=select_client)
select_client_button.place(relx=0.5, rely=0.02)

room_type_label = ttk.Label(reservation_frame, text="Room Type:")
room_type_label.place(relx=0.02, rely=0.1)
room_type_combobox = ttk.Combobox(reservation_frame,
                                  values=["Single", "Double", "Suite"])
room_type_combobox.place(relx=0.1, rely=0.1)

start_date_label = ttk.Label(reservation_frame, text="Start Date:")
start_date_label.place(relx=0.02, rely=0.2)
start_date_entry = ttk.Entry(reservation_frame)
start_date_entry.place(relx=0.1, rely=0.2)

end_date_label = ttk.Label(reservation_frame, text="End Date:")
end_date_label.place(relx=0.02, rely=0.3)
end_date_entry = ttk.Entry(reservation_frame)
end_date_entry.place(relx=0.1, rely=0.3)

book_button = ttk.Button(reservation_frame,
                         text="Book Room",
                         command=book_room)
book_button.place(relx=0.1, rely=0.4)

reserved_rooms_label = ttk.Label(reservation_frame, text="Reserved Rooms:")
reserved_rooms_label.place(relx=0.5, rely=0.48)

reserved_rooms_listbox = tk.Listbox(reservation_frame)
reserved_rooms_listbox.place(relx=0.5,
                             rely=0.56,
                             relwidth=0.45,
                             relheight=0.42)

cancel_reservation_button = ttk.Button(reservation_frame,
                                       text="Cancel Reservation",
                                       command=cancel_reservation)
cancel_reservation_button.place(relx=0.2, rely=0.4)


calendar = Calendar(calendar_frame,
                    selectmode='day',
                    year=2022,
                    month=1,
                    day=1)
calendar.pack(fill='both', expand=True)

calendar.bind('<<CalendarSelected>>', lambda event: display_reserved_rooms(calendar.get_date()))


card_number_label = ttk.Label(card_frame, text="Card Number:")
card_number_label.place(relx=0.02, rely=0.02)
card_number_entry = ttk.Entry(card_frame)
card_number_entry.place(relx=0.1, rely=0.02)

exp_date_label = ttk.Label(card_frame, text="Exp. Date:")
exp_date_label.place(relx=0.02, rely=0.2)
exp_date_entry = ttk.Entry(card_frame)
exp_date_entry.place(relx=0.1, rely=0.2)

ccv_label = ttk.Label(card_frame, text="CCV:")
ccv_label.place(relx=0.02, rely=0.38)
ccv_entry = ttk.Entry(card_frame)
ccv_entry.place(relx=0.1, rely=0.38)

add_card_button = ttk.Button(card_frame, text="Add Card", command=add_card)
add_card_button.place(relx=0.1, rely=0.56)

delete_card_button = ttk.Button(card_frame,
                                text="Delete Card",
                                command=delete_card)
delete_card_button.place(relx=0.25, rely=0.56)

cards_listbox = tk.Listbox(card_frame)
cards_listbox.place(relx=0.5, rely=0.02, relwidth=0.45, relheight=0.45)

error_label = tk.Label(root, text="")
error_label.place(relx=0.5, rely=0.56)
client_frame.pack()
root.mainloop()
