# from datetime import time, datetime
# import tkinter
# import pickle
# from tkinter import messagebox, filedialog
#
#
# class Bankcard:
#     __id = ""
#     __f_name = ""
#     __l_name = ""
#     __month = 0
#     __year = 0
#     __balance = 0
#
#     def __init__(self, id, f_name, l_name, month, year, balance):
#         self.__id = id
#         self.__f_name = f_name
#         self.__l_name = l_name
#         self.__month = month
#         self.__year = year
#         self.__balance = balance
#
#     def __str__(self):
#         result = f"{self.__id} {self.__f_name} {self.__balance}"
#         return result
#
#     def set_f_name(self, f_name):
#         self.__f_name = f_name
#
#     def get_f_name(self):
#         return self.__f_name
#
#     def set_l_name(self, l_name):
#         self.__l_name = l_name
#
#     def get_l_name(self):
#         return self.__l_name
#
#     def set_id(self, id: str):
#         self.__id = id
#
#     def get_id(self):
#         return self.__id
#
#     def set_month(self, month: int):
#         if month >= 1 and month <= 12:
#             self.__month = month
#         else:
#             self.__month = 1
#
#     def get_month(self):
#         return self.__month
#
#     def set_year(self, year):
#         if year >= 1900 and year <= 2028:
#             self.__year = year
#         else:
#             self.__year = 2028
#
#     def get_year(self):
#         return self.__year
#
#     def set_balance(self, balance: int):
#         if balance >= 0:
#             self.__balance = balance
#         else:
#             self.__balance = 0
#
#     def get_balance(self):
#         return self.__balance
#
#     def withdraw(self, money: int) -> bool:
#         is_success = False
#         if money > 0 and money <= self.__balance:
#             self.__balance -= money
#             is_success = True
#         return is_success
#
#     def deposit(self, money: int) -> bool:
#         is_success = False
#         if money >= 0:
#             self.__balance += money
#             is_success = True
#         return is_success
#
#
# class Laptop:
#     def __init__(self, brand, model, price, processor, graphics_card, memory, ssd, screen, quantity):
#         self.__brand = brand
#         self.__model = model
#         self.__price = price
#         self.__processor = processor
#         self.__graphics_card = graphics_card
#         self.__memory = memory
#         self.__ssd = ssd
#         self.__screen = screen
#         self.__quantity = quantity
#
#     def get_quantity(self):
#         return self.__quantity
#
#     def set_quantity(self, quantity):
#         self.__quantity = quantity
#
#     def get_brand(self):
#         return self.__brand
#
#     def set_brand(self, brand):
#         self.__brand = brand
#
#     def get_model(self):
#         return self.__model
#
#     def set_model(self, model):
#         self.__model = model
#
#     def get_price(self):
#         return self.__price
#
#     def set_price(self, price):
#         self.__price = price
#
#     def get_processor(self):
#         return self.__processor
#
#     def set_processor(self, processor):
#         self.__processor = processor
#
#     def get_graphics_card(self):
#         return self.__graphics_card
#
#     def set_graphics_card(self, graphics_card):
#         self.__graphics_card = graphics_card
#
#     def get_memory(self):
#         return self.__memory
#
#     def set_memory(self, memory):
#         self.__memory = memory
#
#     def get_ssd(self):
#         return self.__ssd
#
#     def set_ssd(self, ssd):
#         self.__ssd = ssd
#
#     def get_screen(self):
#         return self.__screen
#
#     def set_screen(self, screen):
#         self.__screen = screen
#
#     def __str__(self):
#         return f"{self.__brand} {self.__model} - ${self.__price}"
#
#     def get_all(self):
#         return f"{self.__brand} {self.__model} \n{self.__processor} | {self.__graphics_card} | {self.__ssd} | {self.__screen} | ${self.__price} | \nКоличество - {self.__quantity}"
#
#
# class Customer:
#     __id = ""
#     __f_name = ""
#     __l_name = ""
#     __bank_cards = list()
#
#     def __init__(self, id: str, f_name: str, l_name: str, bank_cards: list[Bankcard]):
#         self.__id = id
#         self.__f_name = f_name
#         self.__l_name = l_name
#         self.__bank_cards = bank_cards
#         self.__cart = {}
#
#     def view_cart(self):
#         return self.__cart
#
#     def add_to_cart(self, laptop: Laptop, quantity: int):
#         if laptop in self.__cart:
#             self.__cart[laptop] += quantity
#         else:
#             self.__cart[laptop] = quantity
#
#     def remove_from_cart(self, laptop: Laptop, quantity: int):
#         if laptop in self.__cart:
#             self.__cart[laptop] -= quantity
#             if self.__cart[laptop] <= 0:
#                 del self.__cart[laptop]
#
#     def empty_cart(self):
#         self.__cart.clear()
#
#     def calculate_cart_total(self):
#         total = 0
#         for laptop, quantity in self.__cart.items():
#             total += laptop.get_price() * quantity
#         return total
#
#     def purchase(self):
#         total_cost = self.calculate_cart_total()
#         cards = self.get_bank_cards()
#         for card in cards:
#             if card.get_balance() >= total_cost:
#                 card.withdraw(total_cost)
#                 for laptop, quantity in self.__cart.items():
#                     laptop_quantity = database.find_laptop(laptop.get_model()).get_quantity()
#                     database.find_laptop(laptop.get_model()).set_quantity(laptop_quantity - quantity)
#                 self.empty_cart()
#                 return True
#         return False
#
#     def __str__(self):
#         result = f"{self.__id} {self.__f_name} {self.__l_name}"
#         return result
#
#     def set_id(self, some_id):
#         self.__id = some_id
#
#     def get_id(self):
#         return self.__id
#
#     def set_f_name(self, f_name):
#         self.__f_name = f_name
#
#     def get_f_name(self):
#         return self.__f_name
#
#     def set_l_name(self, l_name):
#         self.__l_name = l_name
#
#     def get_l_name(self):
#         return self.__l_name
#
#     def set_bank_cards(self, bank_cards: list[Bankcard]):
#         self.__bank_cards = bank_cards
#
#     def get_bank_cards(self):
#         return self.__bank_cards
#
#     def find_card_index_by_id(self, card_id: str):
#         index = -1
#         for i in range(len(self.__bank_cards)):
#             if self.__bank_cards[i].get_id() == card_id:
#                 index = i
#                 break
#         return index
#
#     def find_card_by_id(self, card_id: str) -> Bankcard:
#         index = self.find_card_index_by_id(card_id)
#         if index == -1:
#             bank_card = None
#         else:
#             bank_card = self.__bank_cards[index]
#         return bank_card
#
#     def add_bank_card(self, new_card: Bankcard) -> bool:
#         is_success = False
#         index = self.find_card_index_by_id(new_card.get_id())
#         if index == -1:
#             self.__bank_cards.append(new_card)
#             is_success = True
#         return is_success
#
#     def change_bank_card_by_id(self, current_card_id: str, new_card: Bankcard) -> bool:
#         is_success = False
#         index = self.find_card_index_by_id(current_card_id)
#         if index != -1:
#             index_new_card = self.find_card_index_by_id(new_card.get_id())
#             if index_new_card == -1 or index_new_card == index:
#                 self.__bank_cards[index] = new_card
#                 is_success = True
#         return is_success
#
#     def remove_bank_card_by_id(self, card_id: str) -> bool:
#         is_success = False
#         index = self.find_card_index_by_id(card_id)
#         if index != -1:
#             del self.__bank_cards[index]
#             is_success = True
#         return is_success
#
#     def deposit_card_by_id(self, card_id: str, money: int) -> bool:
#         is_success = False
#         index = self.find_card_index_by_id(card_id)
#         if index != -1:
#             is_success = self.__bank_cards[index].deposit(money)
#         return is_success
#
#     def withdraw_card_by_id(self, card_id: str, money: int) -> bool:
#         is_success = False
#         index = self.find_card_index_by_id(card_id)
#         if index != -1:
#             is_success = self.__bank_cards[index].withdraw(money)
#         return is_success
#
#
# class Database:
#     def __init__(self):
#         self.__laptops = []
#         self.__list_customers = []
#
#     def add_laptop(self, new_laptop: Laptop) -> bool:
#         is_success = False
#         index = self.find_laptop_index(new_laptop.get_model())
#         if index == -1:
#             self.__laptops.append(new_laptop)
#             is_success = True
#         return is_success
#
#     def get_list_laptops(self):
#         return self.__laptops
#
#     def find_laptop_index(self, laptop_model):
#         index = -1
#         for i in range(len(self.__laptops)):
#             if self.__laptops[i].get_model() == laptop_model:
#                 index = i
#                 break
#         return index
#
#     def find_laptop(self, laptop_model: str) -> Laptop:
#         index = self.find_laptop_index(laptop_model)
#         if index == -1:
#             laptop = None
#         else:
#             laptop = self.__laptops[index]
#         return laptop
#
#     def change_laptop(self, current_laptop_model: str, new_laptop: Laptop) -> bool:
#         is_success = False
#         index = self.find_laptop_index(current_laptop_model)
#         if index != -1:
#             index_new_laptop = self.find_customer_index_by_id(new_laptop.get_model())
#             if index_new_laptop == -1 or index_new_laptop == index:
#                 self.__laptops[index] = new_laptop
#                 is_success = True
#         return is_success
#
#     def remove_laptop(self, laptop_model: str) -> bool:
#         is_success = False
#         index = self.find_laptop_index(laptop_model)
#         if index != -1:
#             del self.__laptops[index]
#             is_success = True
#         return is_success
#
#     def set_list_customers(self, list_customers: list[Customer]):
#         self.__list_customers = list_customers
#
#     def get_list_customers(self):
#         return self.__list_customers
#
#     def find_customer_index_by_id(self, customer_id):
#         index = -1
#         for i in range(len(self.__list_customers)):
#             if self.__list_customers[i].get_id() == customer_id:
#                 index = i
#                 break
#         return index
#
#     def find_customer_by_id(self, customer_id: str) -> Customer:
#         index = self.find_customer_index_by_id(customer_id)
#         if index == -1:
#             customer = None
#         else:
#             customer = self.__list_customers[index]
#         return customer
#
#     def add_customer(self, new_customer: Customer) -> bool:
#         is_success = False
#         index = self.find_customer_index_by_id(new_customer.get_id())
#         if index == -1:
#             self.__list_customers.append(new_customer)
#             is_success = True
#         return is_success
#
#     def change_customer_by_id(self, current_customer_id: str, new_customer: Customer) -> bool:
#         is_success = False
#         index = self.find_customer_index_by_id(current_customer_id)
#         if index != -1:
#             index_new_customer = self.find_customer_index_by_id(new_customer.get_id())
#             if index_new_customer == -1 or index_new_customer == index:
#                 self.__list_customers[index] = new_customer
#                 is_success = True
#         return is_success
#
#     def remove_customer_by_id(self, customer_id: str) -> bool:
#         is_success = False
#         index = self.find_customer_index_by_id(customer_id)
#         if index != -1:
#             del self.__list_customers[index]
#             is_success = True
#         return is_success
#
#     def save_database(self, database_file_path):
#         with open(database_file_path, "wb") as data_file:
#             pickle.dump(self, data_file)
#
#     def load_database(self, database_file_path):
#         with open(database_file_path, "rb") as data_file:
#             temp_db = pickle.load(data_file)
#
#             self.__list_customers = temp_db.get_list_customers()
#             self.__laptops = temp_db.get_list_laptops()
#
#
# database = Database()
#
# card_1 = Bankcard("5869586958695869", "Max", "Payne", 11, 2028, 7500)
# card_2 = Bankcard("1234123412341234", "Max", "Payne", 11, 2028, 1250)
# card_3 = Bankcard("4098584412345678", "Tom", "Jackson", 12, 2026, 9900)
# card_4 = Bankcard("4321432112341234", "Tom", "Jackson", 12, 2026, 3900)
# card_list_1 = [card_1, card_2]
# card_list_2 = [card_3, card_4]
#
# customer_1 = Customer("ABC123", "Max", "Payne", card_list_1)
# customer_2 = Customer("QWE345", "Tom", "Jackson", card_list_2)
#
# database.add_customer(customer_1)
# database.add_customer(customer_2)
#
#
# laptop1 = Laptop("HP", "Pavilion", 999, "Intel i5", "NVIDIA GTX 1650", "8GB", "256GB", "15.6-inch", 100)
# laptop2 = Laptop("Dell", "XPS", 1499, "Intel i7", "NVIDIA GTX 1660 Ti", "16GB", "512GB", "13.3-inch", 100)
# laptop3 = Laptop("Lenovo", "ThinkPad", 1299, "Intel i7", "AMD Radeon RX 5500M", "16GB", "1TB", "14-inch", 100)
# laptop4 = Laptop("Acer", "Nitro 5", 1899, "Intel i5", "NVIDIA RTX 3070", "16GB", "512GB", "17.3-inch", 100)
#
#
# database.add_laptop(laptop1)
# database.add_laptop(laptop2)
# database.add_laptop(laptop3)
# database.add_laptop(laptop4)
#
#
# root = tkinter.Tk()
# root.title("Скромный магазин ноутбуков")
# root.geometry("820x480")
# root.resizable(False, False)
#
#
# def show_customers():
#     frame_customer.pack_forget()
#     frame_laptops.pack_forget()
#     frame_cart.pack_forget()
#
#     frame_customer.pack(fill="both", expand=True)
#     root.geometry("720x480")
#
#
# def show_laptops():
#     frame_customer.pack_forget()
#     frame_laptops.pack_forget()
#     frame_cart.pack_forget()
#
#     frame_laptops.pack(fill="both", expand=True)
#     root.geometry("820x480")
#
# def exit_program():
#     root.quit()
#
#
# def save_data():
#     file_name = filedialog.asksaveasfilename(initialdir=".", title="Select File", filetypes=(("Data files", "*.dat"), ("All files", "*.*")))
#     if file_name:
#         with open(file_name, "wb") as file:
#             pickle.dump(database, file)
#
#
# def load_data():
#     global database
#     database.load_database("database01.dat")
#     fill_customer_listbox()
#     fill_laptops_listbox()
#
#     file_name = filedialog.askopenfilename(initialdir=".", title="Select File", filetypes=(("Data files", "*.dat"),
#                                                                                           ("All files", "*.*")))
#     if file_name:
#         with open(file_name, "rb") as file:
#             database = pickle.load(file)
#
#
# def show_cart():
#     frame_customer.pack_forget()
#     frame_laptops.pack_forget()
#     frame_cart.pack_forget()
#
#     frame_cart.pack(fill="both", expand=True)
#     root.geometry("820x580")
#
#
# root_menu = tkinter.Menu(root)
# root.config(menu=root_menu)
# show_menu = tkinter.Menu(root_menu, tearoff=False)
# show_menu.add_command(label="Save", command=save_data)
# show_menu.add_command(label="Load", command=load_data)
# show_menu.add_command(label="Clients", command=show_customers)
# show_menu.add_command(label="Laptops", command=show_laptops)
# show_menu.add_command(label="Cart", command=show_cart)
# show_menu.add_separator()
# show_menu.add_command(label="Exit", command=exit_program)
# root_menu.add_cascade(label="Show", menu=show_menu)
#
# frame_customer = tkinter.Frame(root)
# frame_customer.pack(expand=True, fill="both")
#
# customer_listbox = tkinter.Listbox(frame_customer, font=("Arial", 15), height=15)
# customer_listbox.place(x=18, y=20)
#
#
# def fill_customer_listbox():
#     customer_listbox.delete(0, tkinter.END)
#     for customer in database.get_list_customers():
#         customer_listbox.insert(tkinter.END, str(customer))
#
#
# fill_customer_listbox()
#
# customer_id_lbl = tkinter.Label(frame_customer, text="customer ID:", font=("Arial", 15))
# customer_id_lbl.place(x=250, y=20)
# customer_id_entry = tkinter.Entry(frame_customer, font=("Arial", 15), width=10)
# customer_id_entry.place(x=250, y=50)
#
# customer_f_name_lbl = tkinter.Label(frame_customer, text="First Name:", font=("Arial", 15))
# customer_f_name_lbl.place(x=250, y=80)
# customer_f_name_entry = tkinter.Entry(frame_customer, font=("Arial", 15), width=10)
# customer_f_name_entry.place(x=250, y=110)
#
# customer_l_name_lbl = tkinter.Label(frame_customer, text="Last Name:", font=("Arial", 15))
# customer_l_name_lbl.place(x=250, y=140)
# customer_l_name_entry = tkinter.Entry(frame_customer, font=("Arial", 15), width=10)
# customer_l_name_entry.place(x=250, y=170)
#
# customer_info = tkinter.Label(frame_customer, text="Customer info:", font=("Arial", 15))
# customer_info.place(x=400, y=30)
#
#
# def add_customer():
#     new_id = customer_id_entry.get()
#     new_name = customer_f_name_entry.get()
#     new_surname = customer_l_name_entry.get()
#
#     new_customer = Customer(new_id, new_name, new_surname, None)
#
#     if database.add_customer(new_customer):
#         new_customer_listbox = str(new_customer)
#         customer_listbox.insert(tkinter.END, new_customer_listbox)
#
#
# customer_add_button = tkinter.Button(frame_customer, text="ADD", command=add_customer)
# customer_add_button.place(x=20, y=381)
#
#
# def change_customer():
#     new_id = customer_id_entry.get()
#     new_name = customer_f_name_entry.get()
#     new_surname = customer_l_name_entry.get()
#     customer_listbox_ind = customer_listbox.curselection()
#     if len(customer_listbox_ind) > 0:
#         selected_customer = customer_listbox.get(customer_listbox_ind[0])
#
#         customer_id = selected_customer.split()[0]
#         exist_customer = database.find_customer_by_id(customer_id)
#
#         if exist_customer:
#             new_customer = Customer(new_id, new_name, new_surname, exist_customer.get_bank_cards())
#
#             if database.change_customer_by_id(customer_id, new_customer):
#                 new_customer_listbox = f"{new_customer.get_id()} {new_customer.get_f_name()} {new_customer.get_l_name()}"
#                 customer_listbox.delete(customer_listbox_ind[0])
#                 customer_listbox.insert(tkinter.END, new_customer_listbox)
#
#
# change_customer_button = tkinter.Button(frame_customer, text="CHANGE", command=change_customer)
# change_customer_button.place(x=55, y=381)
#
#
# def del_customer():
#     customer_listbox_ind = customer_listbox.curselection()
#
#     if len(customer_listbox_ind) > 0:
#         selected_customer = customer_listbox.get(customer_listbox_ind[0])
#
#         customer_id = selected_customer.split()[0]
#
#         if database.remove_customer_by_id(customer_id):
#             customer_listbox.delete(customer_listbox_ind[0])
#
#
# delete_customer_button = tkinter.Button(frame_customer, text="DELETE", command=del_customer)
# delete_customer_button.place(x=114, y=381)
#
#
# def show_customer():
#     customer_listbox_ind = customer_listbox.curselection()
#     if len(customer_listbox_ind) > 0:
#         selected_customer = customer_listbox.get(customer_listbox_ind[0])
#
#         customer_id = selected_customer.split()[0]
#
#         customer = database.find_customer_by_id(customer_id)
#         if customer:
#             bank_card = customer.get_bank_cards()
#             def cards(bank_card):
#                 for card in bank_card:
#                     return card
#             if bank_card:
#                 customer_data = f"ID: {customer.get_id()}\nName: {customer.get_f_name()}\nSurname: {customer.get_l_name()}\nCard ID: {cards(bank_card)}"
#                 customer_info.config(text=customer_data)
#             else:
#                 customer_data = f"ID: {customer.get_id()}\nName: {customer.get_f_name()}\nSurname: {customer.get_l_name()}\n""No bank card"
#                 customer_info.config(text=customer_data)
#
#
# customer_info_button = tkinter.Button(frame_customer, text="SHOW INFO", command=show_customer)
# customer_info_button.place(x=163, y=381)
#
#
# frame_laptops = tkinter.Frame(root)
# frame_laptops.pack_forget()
#
# laptops_listbox = tkinter.Listbox(frame_laptops, font=("Arial", 15), height=15)
# laptops_listbox.place(x=18, y=20)
#
#
# def fill_laptops_listbox():
#     laptops_listbox.delete(0, tkinter.END)
#     for laptop in database.get_list_laptops():
#         laptops_listbox.insert(tkinter.END, str(laptop))
#
#
# fill_laptops_listbox()
#
# laptop_model_lbl = tkinter.Label(frame_laptops, text="laptop model:", font=("Arial", 15))
# laptop_model_lbl.place(x=250, y=0)
# laptop_model_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
# laptop_model_entry.place(x=250, y=30)
#
# laptop_brand_lbl = tkinter.Label(frame_laptops, text="Brand:", font=("Arial", 15))
# laptop_brand_lbl.place(x=250, y=60)
# laptop_brand_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
# laptop_brand_entry.place(x=250, y=90)
#
# laptop_processor_lbl = tkinter.Label(frame_laptops, text="Processor:", font=("Arial", 15))
# laptop_processor_lbl.place(x=250, y=120)
# laptop_processor_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
# laptop_processor_entry.place(x=250, y=150)
#
# laptop_graphics_card_lbl = tkinter.Label(frame_laptops, text="Graphics_card:", font=("Arial", 15))
# laptop_graphics_card_lbl.place(x=250, y=180)
# laptop_graphics_card_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=5)
# laptop_graphics_card_entry.place(x=250, y=210)
#
# laptop_memory_lbl = tkinter.Label(frame_laptops, text="Memory: ", font=("Arial", 15))
# laptop_memory_lbl.place(x=250, y=240)
# laptop_memory_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
# laptop_memory_entry.place(x=250, y=270)
#
# laptop_ssd_lbl = tkinter.Label(frame_laptops, text="SSD: ", font=("Arial", 15))
# laptop_ssd_lbl.place(x=250, y=300)
# laptop_ssd_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
# laptop_ssd_entry.place(x=250, y=330)
#
# laptop_screen_lbl = tkinter.Label(frame_laptops, text="Screen: ", font=("Arial", 15))
# laptop_screen_lbl.place(x=250, y=360)
# laptop_screen_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
# laptop_screen_entry.place(x=250, y=390)
#
# laptop_quantity_lbl = tkinter.Label(frame_laptops, text="Quantity: ", font=("Arial", 15))
# laptop_quantity_lbl.place(x=380, y=300)
# laptop_quantity_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
# laptop_quantity_entry.place(x=380, y=330)
#
# laptop_price_lbl = tkinter.Label(frame_laptops, text="Price: ", font=("Arial", 15))
# laptop_price_lbl.place(x=380, y=360)
# laptop_price_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
# laptop_price_entry.place(x=380, y=390)
#
# laptop_info = tkinter.Label(frame_laptops, text="laptop info:", font=("Arial", 15))
# laptop_info.place(x=400, y=30)
#
#
# def add_laptop():
#     new_model = laptop_model_entry.get()
#     new_brand = laptop_brand_entry.get()
#     new_processor = laptop_processor_entry.get()
#     new_graphics_card = laptop_graphics_card_entry.get()
#     new_memory = laptop_memory_entry.get()
#     new_ssd = laptop_ssd_entry.get()
#     new_screen = laptop_screen_entry.get()
#     new_quantity = laptop_quantity_entry.get()
#     new_price = laptop_price_entry.get()
#
#     new_laptop = Laptop(new_model, new_brand, new_processor, new_graphics_card, new_memory, new_ssd, new_screen, new_quantity, new_price)
#
#     if database.add_laptop(new_laptop):
#         new_laptop_listbox = str(new_laptop)
#         laptops_listbox.insert(tkinter.END, new_laptop_listbox)
#
#
# laptop_add_button = tkinter.Button(frame_laptops, text="ADD", command=add_laptop)
# laptop_add_button.place(x=20, y=381)
#
#
# def change_laptop():
#     new_model = laptop_model_entry.get()
#     new_brand = laptop_brand_entry.get()
#     new_processor = laptop_processor_entry.get()
#     new_graphics_card = laptop_graphics_card_entry.get()
#     new_memory = laptop_memory_entry.get()
#     new_ssd = laptop_ssd_entry.get()
#     new_screen = laptop_screen_entry.get()
#     new_quantity = laptop_quantity_entry.get()
#     new_price = laptop_price_entry.get()
#     laptop_listbox_ind = laptops_listbox.curselection()
#     if len(laptop_listbox_ind) > 0:
#         selected_laptop = laptops_listbox.get(laptops_listbox_ind[0])
#
#         laptop_model = selected_laptop.split()[0]
#         exist_laptop = database.find_laptop(laptop_model)
#
#         if exist_laptop:
#             new_laptop = Laptop(new_model, new_brand, new_processor, new_graphics_card, new_memory, new_ssd, new_screen, new_quantity, new_price)
#
#             if database.change_laptop(laptop_model, new_laptop):
#                 new_laptops_listbox = f"{new_laptop.get_model()} {new_laptop.get_brand()} ${new_laptop.get_price()}"
#                 laptops_listbox.delete(laptop_listbox_ind[0])
#                 laptops_listbox.insert(tkinter.END, new_laptops_listbox)
#
#
# laptop_change_button = tkinter.Button(frame_laptops, text="CHANGE", command=change_laptop)
# laptop_change_button.place(x=55, y=381)
#
#
# def del_laptop():
#     laptop_listbox_ind = laptops_listbox.curselection()
#     if len(laptop_listbox_ind) > 0:
#         selected_laptop = laptops_listbox.get(laptop_listbox_ind[0])
#
#         laptop_model = selected_laptop.split()[0]
#
#         if database.remove_laptop(laptop_model):
#             laptops_listbox.delete(laptop_listbox_ind[0])
#
#
# laptop_delete_button = tkinter.Button(frame_laptops, text="DELETE", command=del_laptop)
# laptop_delete_button.place(x=114, y=381)
#
#
# def show_laptop():
#     laptop_listbox_ind = laptops_listbox.curselection()
#     if len(laptop_listbox_ind) > 0:
#         selected_laptop = laptops_listbox.get(laptop_listbox_ind[0])
#
#         laptop_model = selected_laptop.split()[0]
#
#         laptop = database.find_laptop(laptop_model)
#
#         if laptop:
#             laptop_data = f"{laptop.get_model()}asd"
#             laptop_info.config(text=laptop_data)
#
#
# laptop_show_info_button = tkinter.Button(frame_laptops, text="SHOW INFO", command=show_laptop)
# laptop_show_info_button.place(x=163, y=381)
#
#
# frame_cart = tkinter.Frame(root)
# frame_cart.pack_forget()
#
# listbox_laptops = tkinter.Listbox(frame_cart, width=50)
# listbox_laptops.grid(row=0, column=0, padx=10, pady=10)
#
# for laptop in database.get_list_laptops():
#     listbox_laptops.insert(tkinter.END, str(laptop))
#
#
# def add_to_cart():
#     selected_laptop = laptops_listbox.get(tkinter.ACTIVE)
#     selected_quantity = int(entry_quantity.get())
#     selected_laptop_object = None
#     for laptop in database.get_list_laptops():
#         if str(laptop) == selected_laptop:
#             selected_laptop_object = laptop
#             if selected_quantity <= laptop.get_quantity():
#                 laptop.set_quantity(laptop.get_quantity()-selected_quantity)
#                 break
#             else:
#                 selected_laptop_object = None
#     if selected_laptop_object != None:
#         current_customer.add_to_cart(selected_laptop_object, selected_quantity)
#         label_status.config(text=f"Ноутбук {selected_laptop} добавлен в корзину")
#         label_details.config(text="")
#         label_cart.config(text="")
#     else:
#         label_status.config(text="Ошибка: Данного количества ноутбуков нет в наличии")
#         label_details.config(text="")
#         label_cart.config(text="")
#
#
# def view_details():
#     selected_laptop = listbox_laptops.get(tkinter.ACTIVE)
#     selected_laptop_object = None
#     for laptop in database.get_list_laptops():
#         if str(laptop) == selected_laptop:
#             selected_laptop_object = laptop.get_all()
#             break
#     if selected_laptop_object:
#         label_details.config(text=f"Характеристики:\n{selected_laptop_object}")
#         label_status.config(text="")
#         label_cart.config(text="")
#     else:
#         label_status.config(text="")
#         label_details.config(text="Ошибка: Выберите ноутбук для просмотра")
#         label_cart.config(text="")
#
#
#
# def show_cart():
#     cart_contents = ""
#     for laptop, quantity in current_customer.view_cart().items():
#         cart_contents += f"{laptop} - Количество: {quantity}\n"
#
#     cart_contents += f"Итого: ${current_customer.calculate_cart_total()}"
#     label_cart.config(text=cart_contents)
#     label_status.config(text="")
#     label_details.config(text="")
#
#
# def purchase():
#     purchase_success = current_customer.purchase()
#
#     if purchase_success:
#         label_status.config(text="Покупка успешно завершена")
#         label_cart.config(text="")
#         label_details.config(text="")
#     else:
#         label_status.config(text="Ошибка: Недостаточно средств на карте для покупки")
#         label_cart.config(text="")
#         label_details.config(text="")
#
#
# def show_customer_details(customer):
#     label_customer_info.config(text=str(customer))
#     cards_info = ""
#     for card in customer.get_bank_cards():
#         cards_info += f"ID: {card.get_id()}, Имя клиента: {card.get_f_name()} {card.get_l_name()}, Баланс: ${card.get_balance()}\n"
#     label_cards_info.config(text=cards_info)
#
#
# def clear_cart():
#     global current_customer
#     current_customer.empty_cart()
#     label_cart.config(text="Корзина очищена")
#     label_status.config(text="")
#     label_details.config(text="")
#
#
# listbox_customers = tkinter.Listbox(frame_cart, width=50)
# listbox_customers.grid(row=0, column=2, padx=10, pady=10)
#
# for customer in database.get_list_customers():
#     listbox_customers.insert(tkinter.END, str(customer))
#
#
# def select_customer(event):
#     global current_customer
#     selected_index = listbox_customers.curselection()
#     selected_customer = database.get_list_customers()[selected_index[0]]
#     current_customer = selected_customer
#     show_customer_details(current_customer)
#
#
# listbox_customers.bind("<<ListboxSelect>>", select_customer)
#
#
# def show_customer_details(customer):
#     label_customer_info.config(text=str(customer))
#     cards_info = ""
#     for card in customer.get_bank_cards():
#         cards_info += f"ID: {card.get_id()}, Имя владельца: {card.get_f_name()} {card.get_l_name()}, Баланс: ${card.get_balance()}\n"
#     label_cards_info.config(text=cards_info)
#
#
# label_customer_info = tkinter.Label(frame_cart, text="", width=50)
# label_customer_info.grid(row=1, column=2, padx=10, pady=10)
#
# label_cards_info = tkinter.Label(frame_cart, text="", width=50)
# label_cards_info.grid(row=2, column=2, padx=10, pady=10)
#
# customer_listbox.bind("<<ListboxSelect>>", select_customer)
#
# label_customer_info = tkinter.Label(frame_cart, text="", width=50)
# label_customer_info.grid(row=1, column=2, padx=10, pady=10)
#
# label_cards_info = tkinter.Label(frame_cart, text="", width=50)
# label_cards_info.grid(row=2, column=2, padx=10, pady=10)
#
# label_quantity = tkinter.Label(frame_cart, text="Количество:")
# label_quantity.grid(row=1, column=0, padx=10, pady=5)
#
# entry_quantity = tkinter.Entry(frame_cart)
# entry_quantity.place(x=220, y=190)
#
# button_add_to_cart = tkinter.Button(frame_cart, text="Добавить в корзину", command=add_to_cart)
# button_add_to_cart.grid(row=2, column=0, padx=10, pady=5)
#
# button_view_details = tkinter.Button(frame_cart, text="Просмотреть характеристики", command=view_details)
# button_view_details.grid(row=3, column=0, padx=10, pady=5)
#
# button_show_cart = tkinter.Button(frame_cart, text="Показать корзину", command=show_cart)
# button_show_cart.grid(row=4, column=0, padx=10, pady=5)
#
# button_purchase = tkinter.Button(frame_cart, text="Купить товары в корзине", command=purchase)
# button_purchase.grid(row=5, column=0, padx=10, pady=5)
#
# button_clear_cart = tkinter.Button(frame_cart, text="Очистить корзину", command=clear_cart)
# button_clear_cart.grid(row=9, column=0, padx=10, pady=5)
#
# label_status = tkinter.Label(frame_cart, text="", width=50)
# label_status.grid(row=6, column=0, padx=10, pady=5)
#
# label_details = tkinter.Label(frame_cart, text="", width=50)
# label_details.grid(row=7, column=0, padx=10, pady=5)
#
# label_cart = tkinter.Label(frame_cart, text="", width=50)
# label_cart.grid(row=8, column=0, padx=10, pady=5)
#
#
# root.mainloop()