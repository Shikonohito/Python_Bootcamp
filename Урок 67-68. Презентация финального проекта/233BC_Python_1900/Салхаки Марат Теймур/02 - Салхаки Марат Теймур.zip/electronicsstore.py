import tkinter
import pickle
from tkinter import messagebox, filedialog
import copy


class Bankcard:
    __id = ""
    __f_name = ""
    __l_name = ""
    __year = 0
    __balance = 0

    def __init__(self, id, f_name, l_name, year, balance):
        self.__id = id
        self.__f_name = f_name
        self.__l_name = l_name
        self.__year = year
        self.set_balance(balance)

    def __str__(self):
        result = f"{self.__id} {self.__f_name} {self.__balance}"
        return result

    def set_f_name(self, f_name):
        self.__f_name = f_name

    def get_f_name(self):
        return self.__f_name

    def set_l_name(self, l_name):
        self.__l_name = l_name

    def get_l_name(self):
        return self.__l_name

    def set_id(self, id: str):
        self.__id = id

    def get_id(self):
        return self.__id

    def set_year(self, year):
        if year >= 1900 and year <= 2028:
            self.__year = year
        else:
            self.__year = 2028

    def get_year(self):
        return self.__year

    def set_balance(self, balance: int):
        if balance >= 0:
            self.__balance = balance
        else:
            self.__balance = 0

    def get_balance(self):
        return self.__balance

    def withdraw(self, money: int) -> bool:
        is_success = False
        if money > 0 and money <= self.__balance:
            self.__balance -= money
            is_success = True
        return is_success

    def deposit(self, money: int) -> bool:
        is_success = False
        if money >= 0:
            self.__balance += money
            is_success = True
        return is_success


class Laptop:
    __quantity = 100
    __id = ""
    __price = 0
    __brand = ""
    __processor = ""
    __graphics_card = ""
    __memory = ""
    __ssd = ""
    __screen = ""

    def __init__(self, brand: str, id: str, price: int, processor: str, graphics_card: str, memory: str, ssd: str, screen: str, quantity: int):
        self.__brand = brand
        self.__id = id
        self.__price = price
        self.__processor = processor
        self.__graphics_card = graphics_card
        self.__memory = memory
        self.__ssd = ssd
        self.__screen = screen
        self.__quantity = quantity

    def get_quantity(self):
        return self.__quantity

    def set_quantity(self, quantity):
        self.__quantity = quantity

    def get_brand(self):
        return self.__brand

    def set_brand(self, brand):
        self.__brand = brand

    def get_id(self):
        return self.__id

    def set_id(self, id):
        self.__id = id

    def get_price(self):
        return self.__price

    def set_price(self, price):
        self.__price = price

    def get_processor(self):
        return self.__processor

    def set_processor(self, processor):
        self.__processor = processor

    def get_graphics_card(self):
        return self.__graphics_card

    def set_graphics_card(self, graphics_card):
        self.__graphics_card = graphics_card

    def get_memory(self):
        return self.__memory

    def set_memory(self, memory):
        self.__memory = memory

    def get_ssd(self):
        return self.__ssd

    def set_ssd(self, ssd):
        self.__ssd = ssd

    def get_screen(self):
        return self.__screen

    def set_screen(self, screen):
        self.__screen = screen

    def __str__(self):
        return f"{self.__brand} {self.__id} - ${self.__price} QTY: {self.__quantity}"

    def get_all(self):
        return f"{self.__brand} {self.__id} \n{self.__processor} | {self.__graphics_card} | {self.__ssd} | {self.__screen} | ${self.__price} | \nКоличество - {self.__quantity}"


class Customer:
    __id = ""
    __f_name = ""
    __l_name = ""
    __bank_card = None
    __customers_products = list()

    def __init__(self, id: str, f_name: str, l_name: str, bank_card):
        self.__id = id
        self.__f_name = f_name
        self.__l_name = l_name
        self.__bank_card = bank_card
        self.__customers_products = list()
        self.__cart = []

    def view_cart(self):
        return self.__cart

    def add_to_cart(self, laptop: Laptop, quantity: int):
        is_success = False
        if laptop.get_quantity() >= quantity:
            new_laptop = copy.copy(laptop)
            new_laptop.set_quantity(quantity)
            laptop.set_quantity(laptop.get_quantity() - quantity)
            self.__cart.append(new_laptop)
            is_success = True
        return is_success, new_laptop

    def empty_cart(self):
        self.__cart.clear()

    def calculate_cart_total(self):
        total = 0
        for laptop in self.__cart:
            total += laptop.get_price() * laptop.get_quantity()
        return total

    def purchase(self):
        total_cost = self.calculate_cart_total()
        if self.__bank_card.get_balance() >= total_cost:
            self.__bank_card.withdraw(total_cost)
            for laptop in self.__cart:
                laptop_quantity = database.find_laptop(laptop.get_id()).get_quantity()
                database.find_laptop(laptop.get_id()).set_quantity(laptop_quantity - laptop.get_quantity())
                self.__customers_products.append(laptop)
            self.empty_cart()
            return True
        return False

    def __str__(self):
        result = f"{self.__id} {self.__f_name} {self.__l_name}"
        return result

    def set_id(self, some_id):
        self.__id = some_id

    def get_id(self):
        return self.__id

    def set_f_name(self, f_name):
        self.__f_name = f_name

    def get_f_name(self):
        return self.__f_name

    def set_l_name(self, l_name):
        self.__l_name = l_name

    def get_l_name(self):
        return self.__l_name

    def set_bank_card(self, bank_card: list[Bankcard]):
        self.__bank_card = bank_card

    def get_bank_card(self):
        return self.__bank_card

    def find_card_by_id(self, card_id):
        if self.__bank_card and self.__bank_card.get_id() == card_id:
            return self.__bank_card
        return None

    def add_card(self, new_card):
        if self.__bank_card is None:
            if new_card.get_year() >= 2023 and new_card.get_year() <= 2028:
                self.__bank_card = new_card
            return True
        else:
            return False

    def change_card(self, new_card: Bankcard):
        is_success = False
        if self.__bank_card:
            if new_card.get_year() >= 2023 and new_card.get_year() <= 2028:
                self.__bank_card = new_card
            is_success = True
        return is_success

    def del_card_by_id(self, card_id):
        is_success = False
        if self.__bank_card and self.__bank_card.get_id() == card_id:
            self.__bank_card = None
            is_success = True
        return is_success

    def deposit_card_by_id(self, card_id: str, money: int) -> bool:
        is_success = False
        if self.find_card_by_id(card_id):
            is_success = self.__bank_card.deposit(money)
        return is_success

    def withdraw_card_by_id(self, card_id: str, money: int) -> bool:
        is_success = False
        if self.find_card_by_id(card_id):
            is_success = self.__bank_card.withdraw(money)
        return is_success


class Database:
    def __init__(self):
        self.__laptops = []
        self.__list_customers = []

    def add_laptop(self, new_laptop: Laptop) -> bool:
        is_success = False
        index = self.find_laptop_index(new_laptop.get_id())
        if index == -1:
            self.__laptops.append(new_laptop)
            is_success = True
        return is_success

    def get_list_laptops(self):
        return self.__laptops

    def find_laptop_index(self, laptop_id):
        index = -1
        for i in range(len(self.__laptops)):
            if self.__laptops[i].get_id() == laptop_id:
                index = i
                break
        return index

    def find_customer_index_by_id(self, customer_id):
        index = -1
        for i in range(len(self.__list_customers)):
            if self.__list_customers[i].get_id() == customer_id:
                index = i
                break
        return index

    def find_laptop(self, laptop_id):
        for laptop in self.__laptops:
            if laptop.get_id() == laptop_id:
                return laptop

    def change_laptop(self, current_laptop_id: str, new_laptop: Laptop) -> bool:
        is_success = False
        index = self.find_laptop_index(current_laptop_id)
        if index != -1:
            index_new_laptop = self.find_customer_index_by_id(new_laptop.get_id())
            if index_new_laptop == -1 or index_new_laptop == index:
                self.__laptops[index] = new_laptop
                is_success = True
        return is_success

    def remove_laptop(self, laptop_id: str) -> bool:
        is_success = False
        index = self.find_laptop_index(laptop_id)
        if index != -1:
            del self.__laptops[index]
            is_success = True
        return is_success

    def set_list_customers(self, list_customers: list[Customer]):
        self.__list_customers = list_customers

    def get_list_customers(self):
        return self.__list_customers

    def find_customer_index_by_id(self, customer_id):
        index = -1
        for i in range(len(self.__list_customers)):
            if self.__list_customers[i].get_id() == customer_id:
                index = i
                break
        return index

    def find_customer_by_id(self, customer_id: str) -> Customer:
        index = self.find_customer_index_by_id(customer_id)
        if index == -1:
            customer = None
        else:
            customer = self.__list_customers[index]
        return customer

    def add_customer(self, new_customer: Customer) -> bool:
        is_success = False
        index = self.find_customer_index_by_id(new_customer.get_id())
        if index == -1:
            self.__list_customers.append(new_customer)
            is_success = True
        return is_success

    def change_customer_by_id(self, current_customer_id: str, new_customer: Customer) -> bool:
        is_success = False
        index = self.find_customer_index_by_id(current_customer_id)
        if index != -1:
            index_new_customer = self.find_customer_index_by_id(new_customer.get_id())
            if index_new_customer == -1 or index_new_customer == index:
                self.__list_customers[index] = new_customer
                is_success = True
        return is_success

    def remove_customer_by_id(self, customer_id: str) -> bool:
        is_success = False
        index = self.find_customer_index_by_id(customer_id)
        if index != -1:
            del self.__list_customers[index]
            is_success = True
        return is_success

    def save_database(self, database_file_path):
        with open(database_file_path, "wb") as data_file:
            pickle.dump(self, data_file)

    def load_database(self, database_file_path):
        with open(database_file_path, "rb") as data_file:
            temp_database = pickle.load(data_file)

            self.__list_customers = temp_database.get_list_customers()
            self.__laptops = temp_database.get_list_laptops()


database = Database()

card_1 = Bankcard("5869586958695869", "Max", "Payne",2028, 15200)
card_2 = Bankcard("4098584412345678", "Tom", "Jackson",2026, 12500)

customer_1 = Customer("ABC123", "Max", "Payne", card_1)
customer_2 = Customer("QWE345", "Tom", "Jackson", card_2)

database.add_customer(customer_1)
database.add_customer(customer_2)


laptop1 = Laptop("HP", "ABCA123", 999, "Intel i5", "NVIDIA GTX 1650", "8GB", "256GB", "15.6-inch", 100)
laptop2 = Laptop("Dell", "ZXC345", 1499, "Intel i7", "NVIDIA GTX 1660 Ti", "16GB", "512GB", "13.3-inch", 100)
laptop3 = Laptop("Lenovo", "QWE123", 1299, "Intel i7", "AMD Radeon RX 5500M", "16GB", "1TB", "14-inch", 100)
laptop4 = Laptop("Acer", "ACB123", 1899, "Intel i5", "NVIDIA RTX 3070", "16GB", "512GB", "17.3-inch", 100)

database.add_laptop(laptop1)
database.add_laptop(laptop2)
database.add_laptop(laptop3)
database.add_laptop(laptop4)


root = tkinter.Tk()
root.title("Electronics store")
root.geometry("820x480")
root.resizable(False, False)


def show_customers():
    frame_laptops.pack_forget()
    frame_cart.pack_forget()
    frame_cards_and_operations.pack_forget()

    frame_customer.pack(fill="both", expand=True)
    root.geometry("820x480")


def show_laptops():
    frame_customer.pack_forget()
    frame_cart.pack_forget()
    frame_cards_and_operations.pack_forget()

    frame_laptops.pack(fill="both", expand=True)
    root.geometry("820x480")


def show_cards_and_operations():
    frame_customer.pack_forget()
    frame_laptops.pack_forget()
    frame_cart.pack_forget()

    frame_cards_and_operations.pack(fill="both", expand=True)
    root.geometry("820x480")


def show_cart():
    frame_customer.pack_forget()
    frame_laptops.pack_forget()
    frame_cart.pack_forget()

    frame_cart.pack(fill="both", expand=True)
    root.geometry("820x480")


def fill_cart_listbox():
    cart_listbox.delete(0, tkinter.END)
    for laptop in database.get_list_laptops():
        cart_listbox.insert(tkinter.END, str(laptop))


def fill_cart_customer_listbox():
    cart_customer_listbox.delete(0, tkinter.END)
    for customer in database.get_list_customers():
        cart_customer_listbox.insert(tkinter.END, str(customer))


def fill_customer_listbox():
    customer_listbox.delete(0, tkinter.END)
    for customer in database.get_list_customers():
        customer_listbox.insert(tkinter.END, str(customer))


def fill_laptops_listbox():
    laptops_listbox.delete(0, tkinter.END)
    for laptop in database.get_list_laptops():
        laptops_listbox.insert(tkinter.END, str(laptop))


def fill_cards_and_operations_listbox():
    cards_and_operations_listbox.delete(0, tkinter.END)
    for customer in database.get_list_customers():
        customer_card = customer.get_bank_card()
        if customer_card is not None:
            customer_card_info = f"{customer_card.get_id()} |{customer_card.get_l_name()} {customer_card.get_balance()}"
            cards_and_operations_listbox.insert(tkinter.END, customer_card_info)


def exit_program():
    if messagebox.askyesno("Save Data Base", "Do you want to save data base?"):
        save_data()
    if messagebox.askyesno("Quit", "Do you want to quit?"):
        root.quit()


def save_data():
    file_name = filedialog.asksaveasfilename(initialdir=".", title="Select File", filetypes=(("Data files", "*.dat"), ("All files", "*.*")))

    if file_name:
        database.save_database(file_name + ".dat")


def load_data():
    file_name = filedialog.askopenfilename(initialdir=".", title="Select File", filetypes=(("Data files", "*.dat"), ("All files", "*.*")))

    if file_name:
        with open(file_name, 'rb') as file:
            global database
            database = pickle.load(file)

        fill_customer_listbox()
        fill_laptops_listbox()
        fill_cards_and_operations_listbox()
        fill_cart_listbox()
        fill_cart_customer_listbox()


root.protocol("WM_DELETE_WINDOW", exit_program)


root_menu = tkinter.Menu(root)
root.config(menu=root_menu)
show_menu = tkinter.Menu(root_menu, tearoff=False)
show_menu.add_command(label="Save", command=save_data)
show_menu.add_command(label="Load", command=load_data)
show_menu.add_command(label="Customers", command=show_customers)
show_menu.add_command(label="Laptops", command=show_laptops)
show_menu.add_command(label="Cart", command=show_cart)
show_menu.add_command(label="Cards", command=show_cards_and_operations)
show_menu.add_separator()
show_menu.add_command(label="Exit", command=exit_program)
root_menu.add_cascade(label="Show", menu=show_menu)

frame_customer = tkinter.Frame(root)
frame_customer.pack(expand=True, fill="both")

customer_listbox = tkinter.Listbox(frame_customer, font=("Arial", 15), height=15)
customer_listbox.place(x=18, y=20)


fill_customer_listbox()

customer_id_lbl = tkinter.Label(frame_customer, text="Customer ID:", font=("Arial", 15))
customer_id_lbl.place(x=250, y=20)
customer_id_entry = tkinter.Entry(frame_customer, font=("Arial", 15), width=10)
customer_id_entry.place(x=250, y=50)

customer_f_name_lbl = tkinter.Label(frame_customer, text="First Name:", font=("Arial", 15))
customer_f_name_lbl.place(x=250, y=80)
customer_f_name_entry = tkinter.Entry(frame_customer, font=("Arial", 15), width=10)
customer_f_name_entry.place(x=250, y=110)

customer_l_name_lbl = tkinter.Label(frame_customer, text="Last Name:", font=("Arial", 15))
customer_l_name_lbl.place(x=250, y=140)
customer_l_name_entry = tkinter.Entry(frame_customer, font=("Arial", 15), width=10)
customer_l_name_entry.place(x=250, y=170)

customer_info = tkinter.Label(frame_customer, text="Customer info:", font=("Arial", 15))
customer_info.place(x=500, y=30)

customer_id_notify = tkinter.Label(frame_customer, text="", font=("Arial", 12), fg="red")
customer_id_notify.place(x=350, y=0)

customer_name_notify = tkinter.Label(frame_customer, text="", font=("Arial", 12), fg="red")
customer_name_notify.place(x=360, y=80)

customer_surname_notify = tkinter.Label(frame_customer, text="", font=("Arial", 12), fg="red")
customer_surname_notify.place(x=360, y=140)


def add_customer():
    new_id = customer_id_entry.get()
    new_name = customer_f_name_entry.get()
    new_surname = customer_l_name_entry.get()

    is_correct_entries = True

    if not new_id.isalnum():
        customer_id_notify.config(text="Invalid characters in ID!", fg="red")
        is_correct_entries = False
    elif not new_id.isupper():
        customer_id_notify.config(text="ID must be in uppercase!", fg="red")
        is_correct_entries = False
    else:
        customer_id_notify.config(text="")

    if new_name == "":
        customer_name_notify.config(text="Fill the entry!", fg="red")
        is_correct_entries = False
    else:
        customer_name_notify.config(text="")

    if new_surname == "":
        customer_surname_notify.config(text="Fill the entry!", fg="red")
        is_correct_entries = False
    else:
        customer_surname_notify.config(text="")

        if is_correct_entries:
            new_customer = Customer(new_id, new_name, new_surname, None)

            if database.add_customer(new_customer):
                new_customer_listbox = str(new_customer)
                customer_listbox.insert(tkinter.END, new_customer_listbox)


customer_add_button = tkinter.Button(frame_customer, text="ADD", command=add_customer)
customer_add_button.place(x=20, y=381)


def change_customer():
    new_id = customer_id_entry.get()
    new_name = customer_f_name_entry.get()
    new_surname = customer_l_name_entry.get()
    customer_listbox_ind = customer_listbox.curselection()
    if len(customer_listbox_ind) > 0:
        selected_customer = customer_listbox.get(customer_listbox_ind[0])

        customer_id = selected_customer.split()[0]
        is_correct_entries = True

        if not new_id.isalnum():
            customer_id_notify.config(text="Invalid characters in ID!", fg="red")
            is_correct_entries = False
        elif not new_id.isupper():
            customer_id_notify.config(text="ID must be in uppercase!", fg="red")
            is_correct_entries = False
        else:
            customer_id_notify.config(text="")

        if new_name == "":
            customer_name_notify.config(text="Fill the entry!", fg="red")
            is_correct_entries = False
        else:
            customer_name_notify.config(text="")

        if new_surname == "":
            customer_surname_notify.config(text="Fill the entry!", fg="red")
            is_correct_entries = False
        else:
            customer_surname_notify.config(text="")

            if is_correct_entries:
                new_customer = Customer(new_id, new_name, new_surname, None)

                exist_customer = database.find_customer_by_id(customer_id)

                if exist_customer:
                    new_customer = Customer(new_id, new_name, new_surname, exist_customer.get_bank_card())

                    if database.change_customer_by_id(customer_id, new_customer):
                        new_customer_listbox = f"{new_customer.get_id()} {new_customer.get_f_name()} {new_customer.get_l_name()}"
                        customer_listbox.delete(customer_listbox_ind[0])
                        customer_listbox.insert(tkinter.END, new_customer_listbox)
                        fill_cards_and_operations_listbox()


change_customer_button = tkinter.Button(frame_customer, text="CHANGE", command=change_customer)
change_customer_button.place(x=55, y=381)


def del_customer():
    customer_listbox_ind = customer_listbox.curselection()

    if len(customer_listbox_ind) > 0:
        selected_customer = customer_listbox.get(customer_listbox_ind[0])

        customer_id = selected_customer.split()[0]

        if database.remove_customer_by_id(customer_id):
            customer_listbox.delete(customer_listbox_ind[0])
            fill_cards_and_operations_listbox()


delete_customer_button = tkinter.Button(frame_customer, text="DELETE", command=del_customer)
delete_customer_button.place(x=114, y=381)


def show_customer():
    customer_listbox_ind = customer_listbox.curselection()
    if len(customer_listbox_ind) > 0:
        selected_customer = customer_listbox.get(customer_listbox_ind[0])

        customer_id = selected_customer.split()[0]

        customer = database.find_customer_by_id(customer_id)
        if customer:
            bank_card = customer.get_bank_card()
            if bank_card:
                customer_data = f"ID: {customer.get_id()}\nName: {customer.get_f_name()}\nSurname: {customer.get_l_name()}\nCard ID: {bank_card.get_id()}"
                customer_info.config(text=customer_data)
            else:
                customer_data = f"ID: {customer.get_id()}\nName: {customer.get_f_name()}\nSurname: {customer.get_l_name()}\n""No bank card"
                customer_info.config(text=customer_data)


customer_info_button = tkinter.Button(frame_customer, text="SHOW INFO", command=show_customer)
customer_info_button.place(x=163, y=381)


frame_laptops = tkinter.Frame(root)
frame_laptops.pack_forget()

laptops_listbox = tkinter.Listbox(frame_laptops, font=("Arial", 15), height=15)
laptops_listbox.place(x=18, y=20)


fill_laptops_listbox()

laptop_id_lbl = tkinter.Label(frame_laptops, text="Laptop id:", font=("Arial", 15))
laptop_id_lbl.place(x=250, y=0)
laptop_id_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
laptop_id_entry.place(x=250, y=30)

laptop_brand_lbl = tkinter.Label(frame_laptops, text="Brand:", font=("Arial", 15))
laptop_brand_lbl.place(x=250, y=60)
laptop_brand_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
laptop_brand_entry.place(x=250, y=90)

laptop_processor_lbl = tkinter.Label(frame_laptops, text="Processor:", font=("Arial", 15))
laptop_processor_lbl.place(x=250, y=120)
laptop_processor_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
laptop_processor_entry.place(x=250, y=150)

laptop_graphics_card_lbl = tkinter.Label(frame_laptops, text="Graphics_card:", font=("Arial", 15))
laptop_graphics_card_lbl.place(x=250, y=180)
laptop_graphics_card_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=5)
laptop_graphics_card_entry.place(x=250, y=210)

laptop_memory_lbl = tkinter.Label(frame_laptops, text="Memory: ", font=("Arial", 15))
laptop_memory_lbl.place(x=250, y=240)
laptop_memory_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
laptop_memory_entry.place(x=250, y=270)

laptop_ssd_lbl = tkinter.Label(frame_laptops, text="SSD: ", font=("Arial", 15))
laptop_ssd_lbl.place(x=250, y=300)
laptop_ssd_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
laptop_ssd_entry.place(x=250, y=330)

laptop_screen_lbl = tkinter.Label(frame_laptops, text="Screen: ", font=("Arial", 15))
laptop_screen_lbl.place(x=250, y=360)
laptop_screen_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
laptop_screen_entry.place(x=250, y=390)

laptop_quantity_lbl = tkinter.Label(frame_laptops, text="Quantity: ", font=("Arial", 15))
laptop_quantity_lbl.place(x=380, y=300)
laptop_quantity_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
laptop_quantity_entry.place(x=380, y=330)

laptop_price_lbl = tkinter.Label(frame_laptops, text="Price: ", font=("Arial", 15))
laptop_price_lbl.place(x=380, y=360)
laptop_price_entry = tkinter.Entry(frame_laptops, font=("Arial", 15), width=10)
laptop_price_entry.place(x=380, y=390)

laptop_info = tkinter.Label(frame_laptops, text="Laptop info:", font=("Arial", 15))
laptop_info.place(x=500, y=30)


def add_laptop():
    global new_price, new_quantity
    new_id = laptop_id_entry.get()
    new_brand = laptop_brand_entry.get()
    new_processor = laptop_processor_entry.get()
    new_graphics_card = laptop_graphics_card_entry.get()
    new_memory = laptop_memory_entry.get()
    new_ssd = laptop_ssd_entry.get()
    new_screen = laptop_screen_entry.get()
    new_quantity_str = laptop_quantity_entry.get()
    new_price_str = laptop_price_entry.get()

    new_quantity = new_quantity_str
    new_price = new_price_str

    new_laptop = Laptop(new_brand, new_id, new_price, new_processor, new_graphics_card, new_memory, new_ssd, new_screen, new_quantity)

    if database.add_laptop(new_laptop):
        new_laptop_listbox = str(new_laptop)
        laptops_listbox.insert(tkinter.END, new_laptop_listbox)
        fill_laptops_listbox()


laptop_add_button = tkinter.Button(frame_laptops, text="ADD", command=add_laptop)
laptop_add_button.place(x=20, y=381)


def change_laptop():
    global new_price, new_quantity
    new_id = laptop_id_entry.get()
    new_brand = laptop_brand_entry.get()
    new_processor = laptop_processor_entry.get()
    new_graphics_card = laptop_graphics_card_entry.get()
    new_memory = laptop_memory_entry.get()
    new_ssd = laptop_ssd_entry.get()
    new_screen = laptop_screen_entry.get()
    new_quantity_str = laptop_quantity_entry.get()
    new_price_str = laptop_price_entry.get()
    laptop_listbox_ind = laptops_listbox.curselection()

    new_quantity = new_quantity_str
    new_price = new_price_str

    if len(laptop_listbox_ind) > 0:
        selected_laptop = laptops_listbox.get(laptop_listbox_ind[0])
        laptop_id = selected_laptop.split()[0]
        exist_laptop = database.find_laptop(laptop_id)

        if exist_laptop:
            new_laptop = Laptop(new_brand, new_id, new_price, new_processor, new_graphics_card, new_memory, new_ssd, new_screen, new_quantity)

            if database.change_laptop(laptop_id, new_laptop):
                new_laptops_listbox = f"{new_laptop.get_id()} {new_laptop.get_brand()} ${new_laptop.get_price()}"
                laptops_listbox.delete(laptop_listbox_ind[0])
                laptops_listbox.insert(tkinter.END, new_laptops_listbox)
                fill_laptops_listbox()


laptop_change_button = tkinter.Button(frame_laptops, text="CHANGE", command=change_laptop)
laptop_change_button.place(x=55, y=381)


def del_laptop():
    laptop_listbox_ind = laptops_listbox.curselection()
    if len(laptop_listbox_ind) > 0:
        selected_laptop = laptops_listbox.get(laptop_listbox_ind[0])

        laptop_id = selected_laptop.split()[0]

        if database.remove_laptop(laptop_id):
            laptops_listbox.delete(laptop_listbox_ind[0])


laptop_delete_button = tkinter.Button(frame_laptops, text="DELETE", command=del_laptop)
laptop_delete_button.place(x=114, y=381)


def show_laptop():
    laptop_listbox_ind = laptops_listbox.curselection()
    if len(laptop_listbox_ind) > 0:
        selected_laptop = laptops_listbox.get(laptop_listbox_ind[0])

        laptop_id = selected_laptop.split()[0]

        laptop = database.find_laptop(laptop_id)

        if laptop:
            laptop_data = f"{laptop.get_all()}"
            laptop_info.config(text=laptop_data)


laptop_show_info_button = tkinter.Button(frame_laptops, text="SHOW INFO", command=show_laptop)
laptop_show_info_button.place(x=163, y=381)


frame_cart = tkinter.Frame(root)
frame_cart.pack_forget()

cart_listbox = tkinter.Listbox(frame_cart, font=("Arial", 15), height=10)
cart_listbox.place(x=18, y=20)

fill_cart_listbox()


cart_customer_listbox = tkinter.Listbox(frame_cart, font=("Arial", 15), height=7)
cart_customer_listbox.place(x=580, y=20)

fill_cart_customer_listbox()


def view_details():
    selected_laptop = cart_listbox.get(tkinter.ACTIVE)
    selected_laptop_object = None
    for laptop in database.get_list_laptops():
        if str(laptop) == selected_laptop:
            selected_laptop_object = laptop.get_all()
            break
    if selected_laptop_object:
        label_details.config(text=f"Характеристики:\n{selected_laptop_object}")
        label_status.config(text="")
        label_cart.config(text="")
    else:
        label_status.config(text="")
        label_details.config(text="Ошибка: Выберите ноутбук для просмотра")
        label_cart.config(text="")


def add_to_cart():
    selected_laptop = cart_listbox.get(tkinter.ACTIVE)
    selected_quantity = int(cart_quantity_entry.get())
    selected_laptop_object = None
    for laptop in database.get_list_laptops():
        if str(laptop) == selected_laptop:
            selected_laptop_object = laptop
    is_success, new_laptop = select_customer().add_to_cart(selected_laptop_object, selected_quantity)
    if is_success:
        label_status.config(text=f"Ноутбук {new_laptop} добавлен в корзину")
        label_details.config(text="")
        label_cart.config(text="")
    else:
        label_status.config(text="Ошибка: Данного количества ноутбуков нет в наличии")
        label_details.config(text="")
        label_cart.config(text="")


def show_cart_list():
    cart_contents = ""
    for laptop in select_customer().view_cart():
        cart_contents += f"{laptop}"

    cart_contents += f" | Итого: ${select_customer().calculate_cart_total()}"
    label_cart.config(text=cart_contents)
    label_status.config(text="")
    label_details.config(text="")


def select_customer():
    global customer
    cart_customer_listbox_ind = cart_customer_listbox.curselection()
    if len(cart_customer_listbox_ind) > 0:
        selected_customer = cart_customer_listbox.get(cart_customer_listbox_ind[0])

        customer_id = selected_customer.split()[0]

        customer = database.find_customer_by_id(customer_id)
        if customer:
            bank_card = customer.get_bank_card()
            if bank_card:
                customer_data = f"ID: {customer.get_id()}\nName: {customer.get_f_name()}\nSurname: {customer.get_l_name()}\nCard ID: {bank_card.get_id()}\nCard Balance: {bank_card.get_balance()}"
                customer_info.config(text=customer_data)
            else:
                customer_data = f"ID: {customer.get_id()}\nName: {customer.get_f_name()}\nSurname: {customer.get_l_name()}\n""No bank card"
                customer_info.config(text=customer_data)
    return customer


def purchase():
    purchase_success = select_customer().purchase()

    if purchase_success:
        label_status.config(text="Покупка успешно завершена")
        label_cart.config(text="")
        label_details.config(text="")
    else:
        label_status.config(text="Ошибка: Недостаточно средств на карте для покупки")
        label_cart.config(text="")
        label_details.config(text="")


def clear_cart():
    select_customer().empty_cart()
    label_cart.config(text="Корзина очищена")
    label_status.config(text="")
    label_details.config(text="")


customer_info = tkinter.Label(frame_cart, text="Customer info:", font=("Arial", 15))
customer_info.place(x=550, y=300)

customer_info_button = tkinter.Button(frame_cart, text="SHOW INFO", command=select_customer)
customer_info_button.place(x=550, y=260)

cart_quantity_lbl = tkinter.Label(frame_cart, text="Quantity:", font=("Arial", 15))
cart_quantity_lbl.place(x=255, y=20)
cart_quantity_entry = tkinter.Entry(frame_cart, font=("Arial", 15), width=10)
cart_quantity_entry.place(x=255, y=50)

button_add_to_cart = tkinter.Button(frame_cart, text="Add to cart", command=add_to_cart)
button_add_to_cart.place(x=255, y=110)
#
button_show_cart = tkinter.Button(frame_cart, text="Show cart", command=show_cart_list)
button_show_cart.place(x=255, y=140)
#
button_purchase = tkinter.Button(frame_cart, text="Purchase", command=purchase)
button_purchase.place(x=255, y=170)
#
button_clear_cart = tkinter.Button(frame_cart, text="Clear cart", command=clear_cart)
button_clear_cart.place(x=255, y=200)

button_view_details = tkinter.Button(frame_cart, text="View details", command=view_details)
button_view_details.place(x=255, y=80)

label_status = tkinter.Label(frame_cart, text="", font=("Arial", 12))
label_status.place(x=70, y=340)

label_details = tkinter.Label(frame_cart, text="", font=("Arial", 12))
label_details.place(x=70, y=340)

label_cart = tkinter.Label(frame_cart, text="", font=("Arial", 12))
label_cart.place(x=70, y=340)


frame_cards_and_operations = tkinter.Frame(root)
frame_cards_and_operations.pack_forget()

cards_and_operations_listbox = tkinter.Listbox(frame_cards_and_operations, font=("Arial", 15), height=15, width=21)
cards_and_operations_listbox.place(x=18, y=20)

fill_cards_and_operations_listbox()

card_customer_id_lbl = tkinter.Label(frame_cards_and_operations, text="Customer ID:", font=("Arial", 15))
card_customer_id_lbl.place(x=255, y=20)
card_customer_id_entry = tkinter.Entry(frame_cards_and_operations, font=("Arial", 15), width=10)
card_customer_id_entry.place(x=255, y=50)

card_id_lbl = tkinter.Label(frame_cards_and_operations, text="Card ID:", font=("Arial", 15))
card_id_lbl.place(x=255, y=80)
card_id_entry = tkinter.Entry(frame_cards_and_operations, font=("Arial", 15), width=10)
card_id_entry.place(x=255, y=110)

card_f_name_lbl = tkinter.Label(frame_cards_and_operations, text="Owner first Name:", font=("Arial", 15))
card_f_name_lbl.place(x=255, y=140)
card_f_name_entry = tkinter.Entry(frame_cards_and_operations, font=("Arial", 15), width=10)
card_f_name_entry.place(x=255, y=170)

card_l_name_lbl = tkinter.Label(frame_cards_and_operations, text="Owner last Name:", font=("Arial", 15))
card_l_name_lbl.place(x=255, y=200)
card_l_name_entry = tkinter.Entry(frame_cards_and_operations, font=("Arial", 15), width=10)
card_l_name_entry.place(x=255, y=230)

card_year_lbl = tkinter.Label(frame_cards_and_operations, text="Expiration Year:", font=("Arial", 15))
card_year_lbl.place(x=255, y=260)
card_year_entry = tkinter.Entry(frame_cards_and_operations, font=("Arial", 15), width=5)
card_year_entry.place(x=255, y=290)

card_balance_lbl = tkinter.Label(frame_cards_and_operations, text="Balance:", font=("Arial", 15))
card_balance_lbl.place(x=255, y=320)
card_balance_entry = tkinter.Entry(frame_cards_and_operations, font=("Arial", 15), width=10)
card_balance_entry.place(x=255, y=350)

card_info = tkinter.Label(frame_cards_and_operations, text="Card Info:", font=("Arial", 15))
card_info.place(x=450, y=20)

card_customer_id_notify = tkinter.Label(frame_cards_and_operations, text="", font=("Arial", 12), fg="red")
card_customer_id_notify.place(x=350, y=20)

card_id_notify = tkinter.Label(frame_cards_and_operations, text="", font=("Arial", 12), fg="red")
card_id_notify.place(x=350, y=80)

owner_first_name_notify = tkinter.Label(frame_cards_and_operations, text="", font=("Arial", 12), fg="red")
owner_first_name_notify.place(x=430, y=140)

owner_last_name_notify = tkinter.Label(frame_cards_and_operations, text="", font=("Arial", 12), fg="red")
owner_last_name_notify.place(x=430, y=200)

expiration_year_notify = tkinter.Label(frame_cards_and_operations, text="", font=("Arial", 12), fg="red")
expiration_year_notify.place(x=540, y=260)

balance_notify = tkinter.Label(frame_cards_and_operations, text="", font=("Arial", 12), fg="red")
balance_notify.place(x=470, y=320)


def change_card():
    customer_id = card_customer_id_entry.get()
    card_id = card_id_entry.get()
    card_f_name = card_f_name_entry.get().capitalize()
    card_l_name = card_l_name_entry.get().capitalize()

    is_correct_entries = True

    if not customer_id.isalnum():
        card_customer_id_notify.config(text="Invalid char!", fg="red")
        is_correct_entries = False
        card_customer_id_notify.config(text="")

    if not card_f_name:
        owner_first_name_notify.config(text="Fill first name!", fg="red")
        is_correct_entries = False
    else:
        owner_first_name_notify.config(text="")

    if not card_l_name:
        owner_last_name_notify.config(text="Fill last name!", fg="red")
        is_correct_entries = False
    else:
        owner_last_name_notify.config(text="")

    if is_correct_entries:
        selected_card_index = cards_and_operations_listbox.curselection()[0]
        customer_index = database.find_customer_index_by_id(customer_id)

        if customer_index != -1:
            selected_customer = database.get_list_customers()[customer_index]

            selected_card = selected_customer.get_bank_card()

            if selected_card:
                current_balance = selected_card.get_balance()
                current_year = selected_card.get_year()

                new_card = Bankcard(card_id, card_f_name, card_l_name, current_year, current_balance)

                if str(new_card) not in cards_and_operations_listbox.get(0, tkinter.END):
                    if selected_customer.change_card(new_card):
                        new_card_listbox = f"{new_card.get_id()} | {new_card.get_l_name()} {new_card.get_balance()}"
                        cards_and_operations_listbox.delete(selected_card_index)
                        cards_and_operations_listbox.insert(selected_card_index, new_card_listbox)
                        fill_cards_and_operations_listbox()


change_card_button = tkinter.Button(frame_cards_and_operations, text="CHANGE", command=change_card)
change_card_button.place(x=55, y=381)


def add_card():
    global year, balance
    customer_id = card_customer_id_entry.get().upper()

    customer_index = database.find_customer_index_by_id(customer_id)

    if customer_index != -1:
        selected_customer = database.get_list_customers()[customer_index]

        card_id = card_id_entry.get().upper()
        card_f_name = card_f_name_entry.get().title()
        card_l_name = card_l_name_entry.get().title()

        year_str = card_year_entry.get()
        balance_str = card_balance_entry.get()

        is_correct_entries = True

        if not customer_id.isalnum():
            card_customer_id_notify.config(text="Invalid char!", fg="red")
            is_correct_entries = False
        else:
            card_customer_id_notify.config(text="")

        if not card_f_name:
            owner_first_name_notify.config(text="Fill first name!", fg="red")
            is_correct_entries = False
        else:
            owner_first_name_notify.config(text="")

        if not card_l_name:
            owner_last_name_notify.config(text="Fill last name!", fg="red")
            is_correct_entries = False
        else:
            owner_last_name_notify.config(text="")

        if not year_str:
            expiration_year_notify.config(text="Fill exp year!", fg="red")
            is_correct_entries = False
        else:
            expiration_year_notify.config(text="")
            year = int(year_str)

        if not balance_str:
            balance_notify.config(text="Fill balance!", fg="red")
            is_correct_entries = False
        else:
            balance_notify.config(text="")
            balance = int(balance_str)

        if is_correct_entries:
            new_card = Bankcard(card_id, card_f_name, card_l_name, year, balance)

            if selected_customer.backend_add_card(new_card):
                new_card_listbox = str(new_card)
                cards_and_operations_listbox.insert(tkinter.END, new_card_listbox)
                fill_cards_and_operations_listbox()


add_card_button = tkinter.Button(frame_cards_and_operations, text="ADD", command=add_card)
add_card_button.place(x=20, y=381)


def del_card():
    customer_id = card_customer_id_entry.get().upper()
    is_correct_entries = True

    if not customer_id.isalnum():
        card_customer_id_notify.config(text="Fill!", fg="red")
        is_correct_entries = False
    elif not customer_id.isupper():
        card_customer_id_notify.config(text="Card customer ID must be in uppercase!", fg="red")
        is_correct_entries = False
    else:
        card_customer_id_notify.config(text="")

    if is_correct_entries:
        customer_index = database.find_customer_index_by_id(customer_id)

        if customer_index != -1:
            selected_customer = database.get_list_customers()[customer_index]

            current_card = selected_customer.get_bank_card()
            if current_card is not None:
                if selected_customer.del_card_by_id(current_card.get_id()):
                    selected_card_index = cards_and_operations_listbox.curselection()
                    cards_and_operations_listbox.delete(selected_card_index)


del_card_button = tkinter.Button(frame_cards_and_operations, text="DELETE", command=del_card)
del_card_button.place(x=114, y=381)


def show_card_info():
    customer_id = card_customer_id_entry.get()

    is_correct_entries = True

    if not customer_id.isalnum():
        card_customer_id_notify.config(text="Fill!", fg="red")
        is_correct_entries = False
    elif not customer_id.isupper():
        card_customer_id_notify.config(text="Card customer ID must be in uppercase!", fg="red")
        is_correct_entries = False
    else:
        card_customer_id_notify.config(text="")

    customer_index = database.find_customer_index_by_id(customer_id)

    if customer_index != -1:
        selected_customer = database.get_list_customers()[customer_index]

        cards_and_operations_listbox_ind = cards_and_operations_listbox.curselection()
        if len(cards_and_operations_listbox_ind) > 0:
            selected_card = selected_customer.get_bank_card()

            card_id = selected_card.get_id()

            card = selected_customer.find_card_by_id(card_id)

            if card:
                card_data = f"Owner ID: {customer_id}\nOwner full name: {selected_customer.get_f_name()} {selected_customer.get_l_name()}\nCard ID: {card.get_id()}\nCard full name: {card.get_f_name()} {card.get_l_name()}\nCard expiration year: {card.get_year()}\nCard balance: {card.get_balance()}"
                card_info.config(text=card_data)


show_card_info_button = tkinter.Button(frame_cards_and_operations, text="SHOW INFO", command=show_card_info)
show_card_info_button.place(x=163, y=381)


root.mainloop()
